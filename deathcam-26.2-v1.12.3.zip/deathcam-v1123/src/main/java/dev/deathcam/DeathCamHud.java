package dev.deathcam;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * Freecam information panel plus the Second Chance hearts, hunger, air bubbles and hotbar. These are drawn by
 * the mod itself (from DeathCam's own values and your local gear) because vanilla's versions read the camera
 * entity's player data, which does not work reliably for the client-only ghost body.
 */
public final class DeathCamHud {
    private DeathCamHud() {}

    private static boolean renderErrorLogged;

    public static void render(GuiGraphicsExtractor graphics, net.minecraft.client.DeltaTracker deltaTracker) {
        try {
            renderInner(graphics);
        } catch (RuntimeException e) { // a HUD bug must never crash the game
            if (!renderErrorLogged) {
                renderErrorLogged = true;
                System.err.println("[deathcam] HUD drawing failed and was skipped: " + e);
                e.printStackTrace();
            }
        }
    }

    private static void renderInner(GuiGraphicsExtractor graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (!DeathCam.isActive()) return;

        if (DeathCam.isSuperLife()) {
            drawSuperLife(graphics, mc);
            drawHotbarSelector(graphics, mc);
        }

        if (!DeathCamConfig.showHud || mc.gui.screen() != null) return;

        Vec3 pos = DeathCam.camera().position();
        Vec3 origin = DeathCam.owner() == null ? pos : DeathCam.owner().position();
        double distance = pos.distanceTo(origin);
        double speed = DeathCam.speed();

        String mode = DeathCam.isGhost() ? (DeathCam.isCrouching() ? " (ghost, crouching)" : " (ghost)") : "";
        String line1 = String.format(java.util.Locale.ROOT, "XYZ: %.1f, %.1f, %.1f", pos.x, pos.y, pos.z);
        String line2 = String.format(java.util.Locale.ROOT, "From death: %.0f m", distance);
        String line3 = String.format(java.util.Locale.ROOT, "Speed: %.2f%s", speed, mode);
        int x = 8;
        int y = 8;
        int width = Math.max(mc.font.width(line1), Math.max(mc.font.width(line2), mc.font.width(line3))) + 12;
        graphics.fill(x - 4, y - 4, x + width, y + 48, 0x90000000);
        graphics.text(mc.font, line1, x, y, 0xFFFFFFFF, true);
        graphics.text(mc.font, line2, x, y + 13, 0xFFFFFFFF, true);
        graphics.text(mc.font, line3, x, y + 26, 0xFFFFFFFF, true);
    }

    // The heart from your picture, 9x9. K = black outline, R = bright red, M = mid red, D = dark red.
    private static final String[] HEART = {
        "..KK.KK..",
        ".KRRKRRK.",
        "KRDRRRDRK",
        "KRDDRDDRK",
        "KMRDRDRMK",
        ".KMRRRMK.",
        "..KMRMK..",
        "...KMK...",
        "....K...."
    };
    private static final int BLACK = 0xFF000000;
    private static final int RED = 0xFFFF1313;
    private static final int MID_RED = 0xFFBB1313;
    private static final int DARK_RED = 0xFF600707;
    private static final int EMPTY = 0xFF2A2A2A;

    /**
     * Animated hotbar selector, drawn over the vanilla selection frame: the selected slot softly pulses in
     * opacity (an inner glow and a fading outline) and/or in size (the outline breathes outwards 0-2 px).
     */
    private static void drawHotbarSelector(GuiGraphicsExtractor g, Minecraft mc) {
        int mode = DeathCamConfig.hotbarAnimation;
        if (mode == 0 || DeathCam.owner() == null) return;
        boolean pulseOpacity = mode == 1 || mode == 3;
        boolean pulseSize = mode == 2 || mode == 3;

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        int slot = Math.max(0, Math.min(8, DeathCam.owner().getInventory().getSelectedSlot()));

        double t = (System.currentTimeMillis() % 1500L) / 1500.0;      // one pulse every 1.5 seconds
        double wave = 0.5 - 0.5 * Math.cos(t * 2.0 * Math.PI);          // 0 -> 1 -> 0, smooth

        // our hotbar's selection frame: 24x24, four pixels outside the slot's 16x16 item area
        int x = w / 2 - 92 + slot * 20;
        int y = h - 23;

        if (pulseOpacity) { // inner glow over the slot, brightest at the peak of the pulse
            int glow = (int) (12 + 56 * wave);
            g.fill(x + 4, y + 4, x + 20, y + 20, (glow << 24) | 0xFFFFFF);
        }

        int grow = pulseSize ? (int) Math.round(2.0 * wave) : 0;
        if (grow > 0) { // outline breathing outwards around the vanilla frame
            int alpha = pulseOpacity ? (int) (90 + 165 * wave) : 230;
            int color = (alpha << 24) | 0xFFFFFF;
            int x0 = x - grow, y0 = y - grow, x1 = x + 24 + grow, y1 = y + 24 + grow;
            g.fill(x0, y0, x1, y0 + 1, color);                 // top
            g.fill(x0, y1 - 1, x1, y1, color);                 // bottom
            g.fill(x0, y0 + 1, x0 + 1, y1 - 1, color);         // left
            g.fill(x1 - 1, y0 + 1, x1, y1 - 1, color);         // right
        }
    }

    private static void drawSuperLife(GuiGraphicsExtractor g, Minecraft mc) {
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();

        int hurt = DeathCam.hurtTicks();
        if (hurt > 0) { // brief red flash when you take damage
            int alpha = Math.min(100, hurt * 10);
            g.fill(0, 0, w, h, (alpha << 24) | 0xC01010);
        }

        boolean flash = hurt > 0 && (hurt / 2) % 2 == 0;
        int hearts = (int) Math.round(DeathCam.superMaxHealth() / 2.0);
        double hp = DeathCam.superHealth();
        int x0 = w / 2 - 91;
        int y0 = h - 39;
        for (int i = 0; i < hearts; i++) {
            double filled = Math.max(0, Math.min(2, hp - i * 2)); // 0, 1 (half) or 2 (full)
            int redCols = filled >= 2 ? 9 : filled >= 1 ? 5 : 0;
            drawHeart(g, x0 + i * 8, y0, redCols, flash);
        }
        drawSwingCooldown(g, w, h);
        drawFood(g, w, h);
        drawAir(g, w, h);
        drawHotbar(g, mc, w, h);
    }

    // ---- hunger, air and hotbar (vanilla layout, drawn by us) ----------------------------------------

    private interface Shade { int at(char ch, boolean filled); }

    // Hunger icons, copied pixel for pixel from the reference pictures (9x9). K = outline.
    private static final String[] FOOD_FULL = {
        "..KK.....",
        ".KabK....",
        "KahroK...",
        "KbromoK..",
        ".KdtmmK..",
        "..KdttK..",
        "...KKKWKK",
        "......KWK",
        "......KK."
    };
    private static final String[] FOOD_HALF = {
        "..KK.....",
        ".KgRK....",
        "KgPDRK...",
        "KggSDBK..",
        ".KgRRNK..",
        "..KgFMK..",
        "...KKKEKK",
        "......KVK",
        "......KK."
    };
    // Air bubbles, drawn after the vanilla look: black outline, bright blue ring with lighter right/bottom edge,
    // dark blue middle, white highlight top left. Burst slots are small dark circles.
    private static final String[] BUBBLE = {
        "...KKK...",
        "..KBBLK..",
        ".KBWWDLK.",
        "KBWDDDDLK",
        "KBDDDDDLK",
        "KBDDDDDLK",
        ".KBDDDLK.",
        "..KLLLK..",
        "...KKK..."
    };
    private static final String[] BUBBLE_EMPTY = {
        ".........",
        ".........",
        "...KKK...",
        "..KGGGK..",
        "..KGGGK..",
        "..KGGGK..",
        "...KKK...",
        ".........",
        "........."
    };

    /** Draws a 9x9 pixel picture. Columns from fromCol on (up to toCol) are "filled"; the rest use the empty look. */
    private static void drawArt(GuiGraphicsExtractor g, String[] art, int x, int y, int fromCol, int toCol, Shade shade) {
        for (int row = 0; row < art.length; row++) {
            String line = art[row];
            int col = 0;
            while (col < line.length()) {
                char ch = line.charAt(col);
                if (ch == '.') { col++; continue; }
                boolean filled = col >= fromCol && col < toCol;
                int color = shade.at(ch, filled);
                int start = col;
                while (col < line.length() && line.charAt(col) != '.'
                        && shade.at(line.charAt(col), col >= fromCol && col < toCol) == color) col++;
                g.fill(x + start, y + row, x + col, y + row + 1, color);
            }
        }
    }

    private static int foodPix(char ch, boolean filled) {
        return switch (ch) {
            case 'K' -> BLACK;
            // full drumstick
            case 'a' -> 0xFFCF3736;
            case 'b' -> 0xFFB71C1C;
            case 'h' -> 0xFFFF8B80;
            case 'r' -> 0xFFD60000;
            case 'o' -> 0xFFB57001;
            case 'm' -> 0xFF9C6901;
            case 'd' -> 0xFF684600;
            case 't' -> 0xFF855900;
            case 'W' -> 0xFFFFFFFF;
            // half-empty drumstick
            case 'g' -> 0xFF282828;
            case 'R' -> 0xFFB21818;
            case 'P' -> 0xFFE8C4A4;
            case 'D' -> 0xFFD42A2A;
            case 'S' -> 0xFFD7977B;
            case 'B' -> 0xFFB98458;
            case 'N' -> 0xFF9D6E44;
            case 'F' -> 0xFF603C1A;
            case 'M' -> 0xFF7B502D;
            case 'E' -> 0xFFE2D5A9;
            case 'V' -> 0xFFFEF7DB;
            default -> EMPTY;
        };
    }

    private static int emptyFoodPix(char ch, boolean filled) {
        return ch == 'K' ? BLACK : 0xFF282828;
    }

    private static int airShade(char ch, boolean filled) {
        return switch (ch) {
            case 'K' -> 0xFF000A1E;
            case 'B' -> 0xFF2995E4;
            case 'L' -> 0xFF75B8E3;
            case 'D' -> 0xFF0A4A76;
            case 'W' -> 0xFFD9F3FF;
            case 'G' -> 0xFF3A3F4A;
            default -> 0xFF2995E4;
        };
    }

    /**
     * Attack-recharge indicator in the style of vanilla's: a 16x4 bar just under the crosshair (same spot as
     * vanilla's), dark outline, grey track, and a glossy white fill that grows left to right. Hidden when full.
     */
    private static void drawSwingCooldown(GuiGraphicsExtractor g, int w, int h) {
        float charge = DeathCam.swingCharge();
        if (charge >= 1.0F) return;
        int x = w / 2 - 8;
        int y = h / 2 - 7 + 16;
        g.fill(x, y, x + 16, y + 4, 0xFF000000);                 // outline (top, bottom and end caps)
        g.fill(x + 1, y + 1, x + 15, y + 3, 0xFF5A5A5A);         // empty track
        int filled = (int) (charge * 14.0F);
        if (filled > 0) {
            g.fill(x + 1, y + 1, x + 1 + filled, y + 2, 0xFFFFFFFF);  // bright top row
            g.fill(x + 1, y + 2, x + 1 + filled, y + 3, 0xFFC4C4C4);  // softer bottom row
        }
    }

    private static void drawFood(GuiGraphicsExtractor g, int w, int h) {
        int food = DeathCam.superFood();
        int xRight = w / 2 + 91;
        for (int i = 0; i < 10; i++) {
            int x = xRight - i * 8 - 9;
            if (food >= 2 * i + 2) drawArt(g, FOOD_FULL, x, h - 39, 0, 9, DeathCamHud::foodPix);
            else if (food == 2 * i + 1) drawArt(g, FOOD_HALF, x, h - 39, 0, 9, DeathCamHud::foodPix);
            else drawArt(g, FOOD_HALF, x, h - 39, 0, 9, DeathCamHud::emptyFoodPix);
        }
    }

    private static void drawAir(GuiGraphicsExtractor g, int w, int h) {
        int air = DeathCam.superAir();
        int max = DeathCam.superAirMax();
        if (air >= max && !DeathCam.isHeadUnderwater()) return; // bubbles only show when diving or just surfaced
        int bubbles = Math.max(0, Math.min(10, (int) Math.ceil(air * 10.0 / max)));
        int xRight = w / 2 + 91;
        for (int i = 0; i < 10; i++) {
            drawArt(g, i < bubbles ? BUBBLE : BUBBLE_EMPTY, xRight - i * 8 - 9, h - 49, 0, 9, DeathCamHud::airShade);
        }
    }

    /** The hotbar shows your local copy of the items you lost; the selection follows the number keys and scroll wheel. */
    private static void drawHotbar(GuiGraphicsExtractor g, Minecraft mc, int w, int h) {
        LocalPlayer owner = DeathCam.owner();
        if (owner == null) return;
        int x = w / 2 - 91;
        int y = h - 22;
        // Matches the reference screenshot: near-black outline, a light bevel around each slot, dark slate interior,
        // and a bright framed selection square that is a little bigger than the other slots.
        final int outline = 0xFF1B261D;
        g.fill(x - 1, y - 1, x + 183, y + 23, outline);
        int selected = owner.getInventory().getSelectedSlot();
        for (int i = 0; i < 9; i++) {
            int cx = x + 1 + i * 20;
            int cy = y + 1;
            g.fill(cx, cy, cx + 20, cy + 20, outline);                       // separator / outline
            g.fill(cx + 1, cy + 1, cx + 19, cy + 19, 0xFF7E847F);            // bevel (lower right, a bit darker)
            g.fill(cx + 1, cy + 1, cx + 18, cy + 2, 0xFFA0A29D);             // bevel top highlight
            g.fill(cx + 1, cy + 1, cx + 2, cy + 18, 0xFFA0A29D);             // bevel left highlight
            g.fill(cx + 2, cy + 2, cx + 18, cy + 18, 0xFF3E4944);            // slot interior
        }
        int selX = x + 3 + selected * 20;
        int selY = y + 3;
        g.fill(selX - 4, selY - 4, selX + 20, selY + 20, 0xFF0A0F1A);        // selection: dark outer edge
        g.fill(selX - 3, selY - 3, selX + 19, selY + 19, 0xFFE4F4F4);        // bright rim
        g.fill(selX - 2, selY - 2, selX + 18, selY + 18, 0xFFA7B8A8);        // light grey ring
        g.fill(selX - 1, selY - 1, selX + 17, selY + 17, 0xFF63705D);        // shaded inner edge
        g.fill(selX, selY, selX + 16, selY + 16, 0xFF3E4944);                // slot interior
        for (int i = 0; i < 9; i++) {
            ItemStack stack = owner.getInventory().getItem(i);
            if (stack.isEmpty()) continue;
            int sx = x + 3 + i * 20;
            g.item(stack, sx, y + 3);
            g.itemDecorations(mc.font, stack, sx, y + 3);
        }
    }

    /** redCols = how many columns (from the left) show the coloured heart; the rest show an empty heart. */
    private static void drawHeart(GuiGraphicsExtractor g, int x, int y, int redCols, boolean flash) {
        int empty = flash ? 0xFFFFFFFF : EMPTY;
        for (int row = 0; row < HEART.length; row++) {
            String line = HEART[row];
            int col = 0;
            while (col < line.length()) {
                char ch = line.charAt(col);
                if (ch == '.') { col++; continue; }
                int color = colorOf(ch, col < redCols, empty);
                int start = col;
                while (col < line.length() && line.charAt(col) != '.'
                        && colorOf(line.charAt(col), col < redCols, empty) == color) col++;
                g.fill(x + start, y + row, x + col, y + row + 1, color);
            }
        }
    }

    private static int colorOf(char ch, boolean filled, int empty) {
        if (ch == 'K') return BLACK;
        if (!filled) return empty;
        return switch (ch) {
            case 'M' -> MID_RED;
            case 'D' -> DARK_RED;
            default -> RED;
        };
    }
}
