package dev.deathcam;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Small client-side settings file stored in config/deathcam.properties. */
public final class DeathCamConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathcam.properties");

    public static final double MIN_SPEED = 0.0;
    public static final double MAX_SPEED = 5.0;

    public static double speed = 0.35;
    public static boolean smoothMovement = true;
    public static boolean showHud = true;
    /** Animated hotbar selector: 0 = off, 1 = opacity pulse, 2 = size pulse, 3 = both. */
    public static int hotbarAnimation = 3;

    private DeathCamConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
            speed = clamp(parseDouble(p.getProperty("speed"), 0.35), MIN_SPEED, MAX_SPEED);
            smoothMovement = Boolean.parseBoolean(p.getProperty("smoothMovement", "true"));
            showHud = Boolean.parseBoolean(p.getProperty("showHud", "true"));
            hotbarAnimation = (int) clamp(parseDouble(p.getProperty("hotbarAnimation"), 3), 0, 3);
        } catch (IOException | IllegalArgumentException ignored) {
            // Defaults remain active if the config cannot be read. Properties#load throws
            // IllegalArgumentException for a malformed unicode escape, which must not crash the game at startup.
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("speed", Double.toString(speed));
        p.setProperty("smoothMovement", Boolean.toString(smoothMovement));
        p.setProperty("showHud", Boolean.toString(showHud));
        p.setProperty("hotbarAnimation", Integer.toString(hotbarAnimation));
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                p.store(out, "DeathCam client settings");
            }
        } catch (IOException ignored) {
            // The mod continues to work with in-memory settings.
        }
    }

    private static double parseDouble(String value, double fallback) {
        try {
            if (value == null) return fallback;
            double d = Double.parseDouble(value.trim());
            // "NaN" parses fine and would poison the camera position, so treat it (and infinities) as invalid
            return Double.isFinite(d) ? d : fallback;
        } catch (NumberFormatException ignored) { return fallback; }
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
