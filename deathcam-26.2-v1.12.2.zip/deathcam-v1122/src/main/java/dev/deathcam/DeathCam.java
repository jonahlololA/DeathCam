package dev.deathcam;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.KeyMapping.Category;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class DeathCam implements ClientModInitializer {
    private static final double SPRINT_MULT = 3.0;
    private static final double SMOOTHING = 0.22;

    private static Marker camera;      // client-only, never added to the world
    private static LocalPlayer owner;  // the dead player we are spectating from
    private static Vec3 velocity = Vec3.ZERO;
    private static double movedSpeed;                    // measured movement for the HUD readout
    private static KeyMapping menuKey;
    private static KeyMapping lostItemsKey;

    // Vanilla "smart" cave culling assumes the camera is somewhere you could actually stand. A noclip camera
    // inside rock confuses it and the terrain/caves flash, so we switch it off while freecam is active.
    private static boolean savedSmartCull;
    private static boolean smartCullSaved;

    // "Reanimate": walk around on the ground like a living player (client-side only, nobody else sees it).
    private static final double GRAVITY = 0.08;
    private static final double WALK_SPEED = 0.2158;   // blocks/tick, vanilla walking speed
    private static final double JUMP_POWER = 0.42;
    private static final double STEP_HEIGHT = 0.6;
    // Blocks you placed/mined/poured locally. Re-applied if the server's version of the spot is drawn over them.
    private static final Map<BlockPos, BlockState> localEdits = new LinkedHashMap<>();
    private static int editTick;
    private static boolean ghostMode;
    private static double ghostVy;
    private static Vec3 ghostH = Vec3.ZERO;            // horizontal velocity (x, z)
    private static final int PUPPET_ID = -123456;       // client-only entity id, never used by the server
    // "Second Chance": a client-side extra life while reanimated (hearts + fall damage). Nothing here touches the server.
    private static final double SUPER_MAX_HEALTH = 20.0; // 10 hearts
    private static boolean superLife;
    private static double superHealth;
    private static int hurtTicks;
    private static int invulnTicks;                      // vanilla-style 10 tick grace period after a hit
    // Second Chance gear: a local copy of your lost items/XP on the (client-only) dead player so the vanilla hotbar,
    // held item and XP bar work, plus local-only mining and block placing.
    private static ItemStack[] ownerBackup;
    private static int savedLevel;
    private static float savedProgress;
    private static boolean gearGiven;
    private static BlockPos miningPos;
    private static float miningProgress;
    private static int miningCooldown;
    private static int placeCooldown;
    private static int eatTicks;
    private static final int GHOST_ID_BASE = -300000;   // client-only entity ids for ghost items
    private static final int MAX_GHOSTS = 48;
    private static final ArrayDeque<Integer> ghostIds = new ArrayDeque<>();
    private static int ghostSeq;
    private static final Map<Integer, ItemStack> ghostItems = new LinkedHashMap<>(); // ghost id -> the item to hand back
    private static boolean attackWasDown;
    private static boolean diedAgainPending;  // the second chance just ran out
    private static boolean diedAgain;         // the death screen should say "You died, again."
    private static boolean toolErrorLogged;

    // Second Chance keeps its own air supply (the client-only body does not reliably tick its own down).
    private static final int AIR_MAX = 300;
    private static int superAir = AIR_MAX;
    private static boolean headUnderwater;
    private static int fireDamageTicks;
    private static boolean ghostCrouching;               // Shift while reanimated and out of the water
    // Second Chance has its own client-side hunger meter; normal Reanimate remains hunger-free.
    private static int superFood = 20;
    private static float superSaturation = 5.0F;
    private static float superExhaustion;
    private static int hungerTick;
    private static int regenTick;
    private static final Set<Integer> hitProjectiles = new HashSet<>();
    private static double fallDistance;
    private static boolean ghostSwimming;               // drives the swimming pose of the ghost body

    private static double stepX, stepZ;                // how far the ghost moved this tick (drives leg animation)
    private static RemotePlayer puppet;                 // the visible ghost body (red outline), ghost mode only
    private static String puppetError;                  // why the ghost body could not be created, shown in the info panel

    // Our own punch animation: the dead player's entity never advances its swing, so we drive it ourselves.
    private static final int SWING_DURATION = 6; // vanilla fist swing length in ticks
    private static boolean swinging;
    private static int swingCooldown, swingCooldownMax; // Second Chance only: ticks until the next punch is allowed
    private static int swingTicks;
    private static float swingProgress, oSwingProgress;

    public static boolean isActive() { return camera != null; }
    /** True from the moment a second chance runs out until you respawn: the death screen then says "You died, again." */
    public static boolean diedAgain() { return diedAgain; }
    public static Marker camera() { return camera; }
    public static boolean isGhost() { return ghostMode; }
    public static boolean isSwimming() { return ghostSwimming; }
    public static RemotePlayer puppet() { return puppet; }
    public static boolean isSuperLife() { return superLife; }
    public static boolean isCrouching() { return ghostCrouching; }
    public static double superHealth() { return superHealth; }
    public static double superMaxHealth() { return SUPER_MAX_HEALTH; }
    public static int hurtTicks() { return hurtTicks; }
    public static int superFood() { return superFood; }
    public static int superSaturation() { return (int) superSaturation; }
    public static int superAir() { return superAir; }
    public static int superAirMax() { return AIR_MAX; }
    public static boolean isHeadUnderwater() { return headUnderwater; }
    /** 0..1 while the swing cooldown is recharging (1 = ready); only meaningful during Second Chance. */
    public static float swingCharge() {
        return swingCooldown <= 0 || swingCooldownMax <= 0 ? 1.0F : 1.0F - (float) swingCooldown / swingCooldownMax;
    }

    /** Turns the extra life on or off. It only works while reanimated. */
    public static void setSuperLife(boolean on) {
        if (on && !ghostMode) return;
        boolean was = superLife;
        superLife = on;
        superHealth = on ? SUPER_MAX_HEALTH : 0;
        hurtTicks = 0;
        invulnTicks = 0;
        swingCooldown = 0;
        localEdits.clear();
        heldKey = "";
        fireDamageTicks = 0;
        superFood = on ? 20 : 0;                 // vanilla starting values: full food, 5 saturation
        superSaturation = on ? 5.0F : 0.0F;
        superExhaustion = 0.0F;
        hungerTick = 0;
        regenTick = 0;
        hitProjectiles.clear();
        fallDistance = 0;
        superAir = AIR_MAX;                      // start with a full air supply
        headUnderwater = false;
        if (on && !was) giveGear(Minecraft.getInstance());
        if (!on) takeGear(Minecraft.getInstance());
    }

    /** Ends Second Chance and takes the local gear back. */
    private static void endSuperLife() {
        superLife = false;
        localEdits.clear();
        takeGear(Minecraft.getInstance());
    }

    private static void giveGear(Minecraft mc) {
        if (gearGiven || owner == null) return;
        ItemStack[] lost = LostItems.lost();
        var ownerInv = owner.getInventory();
        var bodyInv = puppet == null ? null : puppet.getInventory(); // the body may be missing; the hotbar uses YOUR inventory
        int size = ownerInv.getContainerSize();
        ownerBackup = new ItemStack[size];
        for (int i = 0; i < size; i++) ownerBackup[i] = ownerInv.getItem(i).copy();
        savedLevel = owner.experienceLevel;
        savedProgress = owner.experienceProgress;
        if (lost != null) {
            // the SAME stack objects go to both inventories, so using one up shows in the hotbar and in your hand
            int n = Math.min(Math.min(36, lost.length), size);
            for (int i = 0; i < n; i++) {
                ItemStack stack = lost[i] == null ? ItemStack.EMPTY : lost[i].copy();
                ownerInv.setItem(i, stack);
                if (bodyInv != null) bodyInv.setItem(i, stack);
            }
            owner.experienceLevel = LostItems.lostLevel();
            owner.experienceProgress = LostItems.lostProgress();
        }
        if (bodyInv != null) bodyInv.setSelectedSlot(ownerInv.getSelectedSlot());
        gearGiven = true;
    }

    private static void takeGear(Minecraft mc) {
        clearGhosts(mc);
        cancelMining(mc);
        eatTicks = 0;
        if (!gearGiven) return;
        gearGiven = false;
        if (owner != null && ownerBackup != null) {
            var ownerInv = owner.getInventory();
            for (int i = 0; i < ownerBackup.length && i < ownerInv.getContainerSize(); i++) {
                ownerInv.setItem(i, ownerBackup[i]);
            }
            owner.experienceLevel = savedLevel;
            owner.experienceProgress = savedProgress;
        }
        ownerBackup = null;
        if (puppet != null) puppet.getInventory().clearContent();
    }

    private static void recordEdit(BlockPos pos, BlockState state) {
        BlockPos key = pos.immutable();
        localEdits.remove(key);
        localEdits.put(key, state);
        if (localEdits.size() > 2048) { // forget the oldest
            var it = localEdits.keySet().iterator();
            it.next();
            it.remove();
        }
    }

    private static void reapplyLocalEdits(Minecraft mc) {
        if (mc.level == null || localEdits.isEmpty()) return;
        for (Map.Entry<BlockPos, BlockState> e : localEdits.entrySet()) {
            BlockPos pos = e.getKey();
            if (mc.level.hasChunkAt(pos) && mc.level.getBlockState(pos) != e.getValue()) {
                mc.level.setBlock(pos, e.getValue(), 11);
            }
        }
    }

    private static void cancelMining(Minecraft mc) {
        if (miningPos != null && mc.level != null) mc.level.destroyBlockProgress(PUPPET_ID, miningPos, -1);
        miningPos = null;
        miningProgress = 0;
    }

    private static void hurt(Minecraft mc, double amount) {
        if (!superLife) return; // already dead this tick (e.g. drowning then fire): don't end the extra life twice
        superHealth -= amount;
        hurtTicks = 10;
        invulnTicks = 10;
        superExhaustion += 0.1F; // vanilla: taking damage costs a little hunger
        if (superHealth <= 0) {
            superHealth = 0;
            endSuperLife();
            diedAgainPending = true; // handled at the start of the next tick, outside the physics code
        }
    }

    public static double stepX() { return stepX; }
    public static double stepZ() { return stepZ; }

    /**
     * Living entities take their camera yaw from the head rotation, not from yRot, so after turning the ghost
     * body its head has to be turned by the same amount (current and previous value, like Entity.turn does).
     */
    public static void syncHeadYaw(Entity e, float delta) {
        if (e instanceof LivingEntity living) {
            living.yHeadRot += delta;
            living.yHeadRotO += delta;
        }
    }

    /** The entity that mouse-look should rotate: the ghost body when walking, otherwise the freecam. */
    public static Entity lookEntity() { return puppet != null ? puppet : camera; }
    public static LocalPlayer owner() { return owner; }
    public static Vec3 velocity() { return velocity; }
    /** How far the camera or ghost actually moved last tick, in blocks per tick (0 when standing still). */
    public static double speed() { return movedSpeed; }
    public static KeyMapping menuKey() { return menuKey; }
    public static KeyMapping lostItemsKey() { return lostItemsKey; }

    /** True if this key press is the (possibly rebound) DeathCam menu key. */
    public static boolean isMenuKey(KeyEvent event) { return menuKey != null && menuKey.matches(event); }

    private static java.lang.reflect.Field[] bobFields; // xBob, xBobO, yBob, yBobO of the dead player (null until looked up)
    private static boolean bobLookedUp;

    /**
     * Vanilla sways the first-person hands by (look direction - "bob" direction). The bob values are only updated
     * while the player is alive, but Second Chance keeps turning the dead player's look direction to follow you, so the
     * difference grows with every turn and pushes held items sideways off the screen. Called every frame the hands
     * are drawn: it makes the bob values equal to the look direction, so there is no sway offset.
     * Fields are found by reflection, so a rename just leaves the old behaviour instead of breaking the mod.
     */
    public static void neutralizeHandSway() {
        LocalPlayer o = owner;
        if (o == null) return;
        if (!bobLookedUp) {
            bobLookedUp = true;
            String[] names = {"xBob", "xBobO", "yBob", "yBobO"};
            java.lang.reflect.Field[] found = new java.lang.reflect.Field[names.length];
            boolean all = true;
            for (int i = 0; i < names.length; i++) {
                for (Class<?> k = o.getClass(); k != null && found[i] == null; k = k.getSuperclass()) {
                    try {
                        java.lang.reflect.Field f = k.getDeclaredField(names[i]);
                        if (f.getType() == float.class) { f.setAccessible(true); found[i] = f; }
                    } catch (ReflectiveOperationException | RuntimeException ignored) {
                        // not in this class: try its parent
                    }
                }
                if (found[i] == null) all = false;
            }
            bobFields = all ? found : null;
        }
        if (bobFields == null) return;
        try {
            bobFields[0].setFloat(o, o.getXRot());
            bobFields[1].setFloat(o, o.getXRot());
            bobFields[2].setFloat(o, o.getYRot());
            bobFields[3].setFloat(o, o.getYRot());
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            bobFields = null;
        }
    }

    /** Same interpolation vanilla's LivingEntity#getAttackAnim uses, fed by our own swing state. */
    public static float attackAnim(float partialTick) {
        float diff = swingProgress - oSwingProgress;
        if (diff < 0.0F) diff += 1.0F;
        return oSwingProgress + diff * partialTick;
    }

    private static void resetSwing() {
        swinging = false; swingTicks = 0; swingProgress = 0; oSwingProgress = 0;
        swingCooldown = 0; swingCooldownMax = 0;
    }

    /** Vanilla attack speeds (attacks per second) by item: fist 4, sword 1.6, pickaxe 1.2, axes and hoes by tier, etc. */
    private static double heldAttackSpeed() {
        if (owner == null || !gearGiven) return 4.0;
        ItemStack held = owner.getMainHandItem();
        if (held.isEmpty()) return 4.0;
        String id = held.getItem().getDescriptionId();
        id = id.substring(id.lastIndexOf('.') + 1); // e.g. "item.minecraft.diamond_sword" -> "diamond_sword"
        if (id.endsWith("_sword")) return 1.6;
        if (id.endsWith("_pickaxe")) return 1.2;
        if (id.endsWith("_shovel")) return 1.0;
        if (id.endsWith("_axe")) {
            if (id.startsWith("wooden_") || id.startsWith("stone_")) return 0.8;
            return id.startsWith("iron_") ? 0.9 : 1.0;
        }
        if (id.endsWith("_hoe")) {
            if (id.startsWith("stone_")) return 2.0;
            if (id.startsWith("iron_")) return 3.0;
            if (id.startsWith("diamond_") || id.startsWith("netherite_")) return 4.0;
            return 1.0; // wooden, golden
        }
        if (id.equals("trident")) return 1.1;
        if (id.equals("mace")) return 0.6;
        return 4.0;
    }

    /** Vanilla's recharge time: 20 / attack speed ticks, and the attack is ready once (ticks + 0.5) reaches that. */
    private static int swingCooldownTicks() {
        double delay = 20.0 / heldAttackSpeed();
        return Math.max(1, (int) Math.ceil(delay - 0.5));
    }

    private static String heldKey = ""; // kept for compatibility; slot swaps no longer touch the attack cooldown

    private static void startSwing() {
        // The swing animation always plays when you swing. (It used to be skipped while the attack cooldown was
        // still recharging, so swords and tools only animated once the reload bar was full.) Like in vanilla, a
        // swing simply restarts the cooldown instead of being ignored.
        // vanilla rule: allow a new swing if idle or already past the halfway point
        if (!swinging || swingTicks >= SWING_DURATION / 2 || swingTicks < 0) {
            if (superLife) { swingCooldownMax = swingCooldownTicks(); swingCooldown = swingCooldownMax; }
            swingTicks = -1;
            swinging = true;
            if (puppet != null) puppet.swing(InteractionHand.MAIN_HAND); // visible in third person
        }
    }

    private static void tickSwing() {
        if (swingCooldown > 0) swingCooldown--;
        oSwingProgress = swingProgress;
        if (swinging) {
            swingTicks++;
            if (swingTicks >= SWING_DURATION) { swingTicks = 0; swinging = false; }
        } else {
            swingTicks = 0;
        }
        swingProgress = (float) swingTicks / SWING_DURATION;
    }

    @Override
    public void onInitializeClient() {
        DeathCamConfig.load();
        menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.deathcam.open_menu", InputConstants.KEY_F10, Category.MISC));
        lostItemsKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.deathcam.lost_items", InputConstants.KEY_F12, Category.MISC));
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            try { tick(mc); } catch (RuntimeException e) { failSafe(mc, e); }
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            try { endTick(mc); } catch (RuntimeException e) { failSafe(mc, e); }
        });
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("deathcam", "freecam_hud"), DeathCamHud::render);
    }

    public static void enter(Minecraft mc) {
        ItemSupport.writeReportOnce();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isDeadOrDying()) return;
        Marker m = new Marker(p.getType(), mc.level);
        m.setPos(p.getX(), p.getY(), p.getZ());
        m.setYRot(p.getYRot());
        m.setXRot(p.getXRot());
        m.xo = m.getX(); m.yo = m.getY(); m.zo = m.getZ();
        m.yRotO = m.getYRot(); m.xRotO = m.getXRot();
        m.setSilent(true);
        ghostMode = false;
        ghostH = Vec3.ZERO;
        ghostVy = 0;
        superLife = false;
        ghostSwimming = false;
        ghostCrouching = false;
        camera = m;
        owner = p;
        velocity = Vec3.ZERO;
        resetSwing();
        mc.setCameraEntity(m);
        if (!smartCullSaved) {
            savedSmartCull = mc.smartCull;
            smartCullSaved = true;
        }
        mc.smartCull = false;
        mc.gui.setScreen(null); // GuiMixin stops this from reopening the death screen
    }

    /** Leaves freecam without touching any screen (used when the game state changed under us). */
    private static void stop(Minecraft mc) {
        movedSpeed = 0;
        takeGear(mc);
        removePuppet(mc);
        camera = null;
        owner = null;
        velocity = Vec3.ZERO;
        ghostMode = false;
        ghostH = Vec3.ZERO;
        ghostVy = 0;
        superLife = false;
        localEdits.clear();
        heldKey = "";
        headUnderwater = false;
        superAir = AIR_MAX;
        hitProjectiles.clear();
        ghostSwimming = false;
        ghostCrouching = false;
        resetSwing();
        if (smartCullSaved) {
            mc.smartCull = savedSmartCull;
            smartCullSaved = false;
        }
        if (mc.player != null) mc.setCameraEntity(mc.player);
    }

    /** @param showDeathScreen true when the player is still dead and wants the respawn buttons back */
    public static void exit(Minecraft mc, boolean showDeathScreen) {
        if (camera == null) return;
        stop(mc);
        if (showDeathScreen) mc.gui.setScreen(null); // player is dead -> vanilla reopens DeathScreen
    }

    /** Switches between flying freecam and walking as a ghost. */
    public static void setGhostMode(Minecraft mc, boolean on) {
        Marker c = camera;
        if (c == null || mc.level == null) return;
        ghostH = Vec3.ZERO;
        ghostVy = 0;
        stepX = stepZ = 0;
        velocity = Vec3.ZERO;
        endSuperLife();    // the extra life only exists while reanimated
        ghostSwimming = false;
        ghostCrouching = false;
        fallDistance = 0;

        if (on) {
            if (owner != null && (!mc.level.hasChunkAt(c.blockPosition()) || !mc.level.noCollision(c))) {
                // started inside rock or past the loaded area: drop back at the death spot
                c.setPos(owner.getX(), owner.getY(), owner.getZ());
            }
            c.xo = c.getX(); c.yo = c.getY(); c.zo = c.getZ();
            c.noPhysics = false; // Marker starts with collisions off; ghost mode turns them on
            ghostMode = true;
            spawnPuppet(mc, c);
        } else {
            ghostMode = false;
            c.noPhysics = true;
            if (puppet != null) { // keep looking the same way when going back to flying
                c.setYRot(puppet.getYRot());
                c.setXRot(puppet.getXRot());
                c.yRotO = c.getYRot();
                c.xRotO = c.getXRot();
            }
            removePuppet(mc);
            mc.setCameraEntity(c);
        }
    }

    /** Creates the visible ghost body: a client-only player entity with a red glow outline. */
    private static void spawnPuppet(Minecraft mc, Marker c) {
        try {
            spawnPuppetUnchecked(mc, c);
            puppetError = null;
        } catch (RuntimeException | LinkageError e) {
            puppet = null;
            puppetError = e.getClass().getSimpleName() + ": " + e.getMessage();
            System.err.println("[DeathCam] could not create the ghost body: " + puppetError);
            e.printStackTrace();
            mc.gui.hud.setOverlayMessage(Component.literal("DeathCam: could not create the body (" + puppetError + ")"), false);
        }
    }

    private static void spawnPuppetUnchecked(Minecraft mc, Marker c) {
        removePuppet(mc);
        // Different UUID from the real player, otherwise the level refuses the duplicate.
        RemotePlayer p = new RemotePlayer(mc.level, new GameProfile(UUID.randomUUID(), mc.getUser().getName()));
        // Copy the authenticated player's skin/cape texture properties onto the client-only ghost profile.
        // Keep a distinct UUID so the level can contain both the dead player and the reanimated body.
        // The property map of a GameProfile is immutable in current versions and putAll throws, which used to abort
        // the whole spawn (no body, no gear). The skin is also borrowed by AbstractClientPlayerMixin, so this is optional.
        if (mc.player != null) {
            try {
                p.getGameProfile().properties().putAll(mc.player.getGameProfile().properties());
            } catch (RuntimeException ignored) {
                // keep going without copied texture properties
            }
        }
        showAllSkinLayers(p);
        p.setId(PUPPET_ID);
        p.setPos(c.getX(), c.getY(), c.getZ());
        p.setYRot(c.getYRot());
        p.setXRot(c.getXRot());
        p.xo = p.getX(); p.yo = p.getY(); p.zo = p.getZ();
        p.yRotO = p.getYRot(); p.xRotO = p.getXRot();
        p.yHeadRot = p.yHeadRotO = p.getYRot();
        p.yBodyRot = p.yBodyRotO = p.getYRot();
        p.setNoGravity(true);
        p.setGlowingTag(true); // outline colour comes from EntityMixin (red)
        mc.level.addEntity(p);
        puppet = p;
        if (gearGiven && owner != null) { // a re-created body must hold the same local gear again
            int n = Math.min(36, Math.min(owner.getInventory().getContainerSize(), p.getInventory().getContainerSize()));
            for (int i = 0; i < n; i++) p.getInventory().setItem(i, owner.getInventory().getItem(i));
            p.getInventory().setSelectedSlot(owner.getInventory().getSelectedSlot());
        }
        mc.setCameraEntity(p); // vanilla hides the camera entity in first person and shows it in F5 view
    }

    /**
     * A client-only player never receives the "which skin layers are visible" setting from a server, so it
     * defaults to none: no jacket, sleeves, pants or hat, which makes most skins look thin and wrong. Turn all
     * seven layers on. Done by reflection so a renamed field simply leaves the layers off instead of breaking the mod.
     */
    private static void showAllSkinLayers(RemotePlayer p) {
        try {
            for (Class<?> k = p.getClass(); k != null; k = k.getSuperclass()) {
                java.lang.reflect.Field f;
                try {
                    f = k.getDeclaredField("DATA_PLAYER_MODE_CUSTOMISATION");
                } catch (NoSuchFieldException e) {
                    continue;
                }
                f.setAccessible(true);
                Object accessor = f.get(null);
                Object data = p.getEntityData();
                for (java.lang.reflect.Method m : data.getClass().getMethods()) {
                    if (m.getName().equals("set") && m.getParameterCount() == 2) {
                        m.invoke(data, accessor, (byte) 0x7F);
                        return;
                    }
                }
                return;
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // leave the layers off
        }
    }

    private static void removePuppet(Minecraft mc) {
        if (puppet != null && mc.level != null) {
            mc.level.removeEntity(PUPPET_ID, Entity.RemovalReason.DISCARDED);
        }
        puppet = null;
    }

    /** After the world has ticked, move the ghost body to where the physics put it (keeps it smooth). */
    private static void endTick(Minecraft mc) {
        Marker c = camera;
        RemotePlayer p = puppet;
        if (c == null || p == null) return;
        // The ghost body must exist in the level to be drawn: put it back if it was lost, and never let it go invisible.
        if (mc.level != null && mc.level.getEntity(PUPPET_ID) != p) {
            if (p.isRemoved()) { spawnPuppet(mc, c); return; }
            mc.level.addEntity(p);
        }
        p.setInvisible(false);
        p.setGlowingTag(true);
        if (ghostMode && mc.getCameraEntity() != p) mc.setCameraEntity(p); // something reset the camera: take it back

        p.xo = c.xo; p.yo = c.yo; p.zo = c.zo;
        p.setPos(c.getX(), c.getY(), c.getZ());
        // Force the same entity state vanilla uses for sprint-swimming. The renderer's swim
        // animation amount is supplied by LivingEntityMixin so the arms actually stroke.
        p.setSprinting(ghostSwimming);
        p.setSwimming(ghostSwimming);
        if (p.isShiftKeyDown() != ghostCrouching) p.setShiftKeyDown(ghostCrouching);
        // Set the pose directly. The renderer draws vanilla's crouch from it (bent body, lowered head and name,
        // slower leg swing) and the camera takes its lowered eye height from it. Relying on the game's own pose
        // update was not enough for this client-only body, so crouching only showed up as text.
        Pose wanted = ghostSwimming ? Pose.SWIMMING : (ghostCrouching ? Pose.CROUCHING : Pose.STANDING);
        if (p.getPose() != wanted) p.setPose(wanted);
        if (gearGiven && owner != null) { // hotbar keys and the scroll wheel change YOUR selection; mirror it onto the body
            p.getInventory().setSelectedSlot(owner.getInventory().getSelectedSlot());
        }
        if (superLife) { // vanilla's hunger bar draws these values (real textures, shaking, flashing)
            p.getFoodData().setFoodLevel(superFood);
            p.getFoodData().setSaturation(superSaturation);
        }
        p.yBodyRotO = p.yBodyRot;      // body faces where you look
        p.yBodyRot = p.getYRot();
    }

    /** One line describing the ghost body's state, shown in the info panel to help track down visibility problems. */
    public static String bodyDebug(Minecraft mc) {
        RemotePlayer p = puppet;
        if (p == null) return puppetError == null ? "Body: none" : "Body: none (" + puppetError + ")";
        boolean inLevel = mc.level != null && mc.level.getEntity(PUPPET_ID) == p;
        return "Body: inLevel=" + inLevel + " invis=" + p.isInvisible() + " removed=" + p.isRemoved()
                + " cam=" + (mc.getCameraEntity() == p) + " pose=" + p.getPose();
    }

    private static final double CROUCH_HEIGHT = 1.5; // vanilla's crouching hitbox height

    private static void shrinkBox(Marker c) {
        AABB box = c.getBoundingBox();
        c.setBoundingBox(new AABB(box.minX, box.minY, box.minZ, box.maxX, box.minY + CROUCH_HEIGHT, box.maxZ));
    }

    private static boolean fluidAt(Minecraft mc, double x, double y, double z) {
        return !mc.level.getFluidState(BlockPos.containing(x, y, z)).isEmpty();
    }

    private static double horizSq(Vec3 a, Vec3 b) {
        double dx = a.x - b.x, dz = a.z - b.z;
        return dx * dx + dz * dz;
    }

    /** Vanilla's crouch edge safety: shorten the horizontal movement until there is ground within step height below. */
    private static Vec3 backOffFromEdge(Minecraft mc, Marker c, Vec3 m) {
        double dx = m.x, dz = m.z;
        AABB box = c.getBoundingBox();
        while (dx != 0 && mc.level.noCollision(c, box.move(dx, -STEP_HEIGHT, 0))) {
            if (dx < 0.05 && dx >= -0.05) dx = 0; else if (dx > 0) dx -= 0.05; else dx += 0.05;
        }
        while (dz != 0 && mc.level.noCollision(c, box.move(0, -STEP_HEIGHT, dz))) {
            if (dz < 0.05 && dz >= -0.05) dz = 0; else if (dz > 0) dz -= 0.05; else dz += 0.05;
        }
        while (dx != 0 && dz != 0 && mc.level.noCollision(c, box.move(dx, -STEP_HEIGHT, dz))) {
            if (dx < 0.05 && dx >= -0.05) dx = 0; else if (dx > 0) dx -= 0.05; else dx += 0.05;
            if (dz < 0.05 && dz >= -0.05) dz = 0; else if (dz > 0) dz -= 0.05; else dz += 0.05;
        }
        return new Vec3(dx, m.y, dz);
    }

    /**
     * One tick of walking physics for the ghost, using vanilla's numbers: ground acceleration 0.1 (x1.3 sprinting)
     * with 0.546 ground friction, 0.02 air acceleration with 0.91 drag, gravity 0.08 with 0.98 drag, jump 0.42.
     */
    private static void tickGhost(Minecraft mc, Marker c, boolean allowInput) {
        boolean wasOnGround = c.onGround();
        Vec3 start = c.position();

        double f = 0, st = 0;
        boolean jump = false, sneak = false, sprint = false;
        if (allowInput) {
            f = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
            st = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
            jump = mc.options.keyJump.isDown();
            sneak = mc.options.keyShift.isDown();
            sprint = mc.options.keySprint.isDown();
        }

        double yaw = Math.toRadians(c.getYRot());
        Vec3 forward = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 wish = forward.scale(f).add(right.scale(st));
        wish = wish.lengthSqr() > 1.0E-6 ? wish.normalize().scale(0.98) : Vec3.ZERO; // vanilla scales input by 0.98
        boolean canSprint = !superLife || superFood > 6; // vanilla: no sprinting at 6 food or less
        boolean sprinting = sprint && f > 0 && !sneak && canSprint;
        double speedMul = (sprinting ? 1.3 : 1.0) * (sneak ? 0.3 : 1.0);

        // In liquid if the feet or the body are in it.
        boolean inLiquid = fluidAt(mc, c.getX(), c.getY() + 0.1, c.getZ())
                || fluidAt(mc, c.getX(), c.getY() + 0.9, c.getZ());
        boolean swimming = inLiquid && sprinting; // sprint + forward = swim where you look, like vanilla
        ghostSwimming = swimming;
        boolean crouching = sneak && !inLiquid;    // Shift crouches on land (and dives in water)
        // like vanilla: if you let go of Shift under a low ceiling you stay crouched until there is room to stand
        if (!crouching && ghostCrouching && !inLiquid && !mc.level.noCollision(c)) crouching = true;
        ghostCrouching = crouching;

        Vec3 v = ghostH;
        double vy = ghostVy;
        double drag;

        if (inLiquid) {
            if (swimming) {
                // Sprint-swimming follows the camera look direction, like vanilla.
                // Space and Shift remain usable to explicitly rise or dive.
                Vec3 look = c.getLookAngle();
                Vec3 swimWish = new Vec3(look.x, look.y, look.z).scale(0.26);
                if (jump) swimWish = swimWish.add(0, 0.12, 0);
                if (sneak) swimWish = swimWish.add(0, -0.12, 0);
                v = v.add(new Vec3(swimWish.x, 0, swimWish.z).subtract(v).scale(0.2));
                vy += (swimWish.y - vy) * 0.2;
                drag = 0.9;
            } else {
                v = v.add(wish.scale(0.02));
                if (jump) vy += 0.04;   // Space = swim up
                if (sneak) vy -= 0.04;  // Shift = dive
                drag = 0.8;
            }
            vy = Math.max(-0.3, Math.min(0.3, vy));
            // pushing into a ledge with open space above it: hop out of the water (vanilla does this too)
            if (c.horizontalCollision && v.lengthSqr() > 1.0E-8
                    && mc.level.noCollision(c, c.getBoundingBox().move(v.x, STEP_HEIGHT, v.z))) {
                vy = 0.3;
            }
        } else if (wasOnGround) {
            v = v.add(wish.scale(0.1 * speedMul));
            if (jump) {
                vy = JUMP_POWER;
                if (sprinting) v = v.add(forward.scale(0.2)); // vanilla sprint-jump boost
                if (superLife) superExhaustion += sprinting ? 0.2F : 0.05F; // vanilla jump hunger cost
            }
            drag = 0.546;
        } else {
            v = v.add(wish.scale(0.02 * (sprinting ? 1.3 : 1.0)));
            drag = 0.91;
        }

        // crouching on the ground: don't walk off ledges (vanilla's "safe walk")
        if (crouching && wasOnGround) v = backOffFromEdge(mc, c, v);

        // move once with everything combined, like vanilla (crouched = the 1.5 block tall hitbox)
        if (crouching) shrinkBox(c);
        Vec3 before = c.position();
        c.move(MoverType.SELF, new Vec3(v.x, vy, v.z));

        // automatic step-up for slabs, stairs and the like
        if (c.horizontalCollision && wasOnGround && (Math.abs(v.x) > 1.0E-5 || Math.abs(v.z) > 1.0E-5)) {
            Vec3 flat = c.position();
            boolean flatGround = c.onGround();
            boolean flatVertical = c.verticalCollision;
            c.setPos(before);
            if (crouching) shrinkBox(c); // setPos rebuilt the full-height box
            c.move(MoverType.SELF, new Vec3(0, STEP_HEIGHT, 0));
            c.move(MoverType.SELF, new Vec3(v.x, 0, v.z));
            c.move(MoverType.SELF, new Vec3(0, -STEP_HEIGHT - 0.01, 0));
            if (horizSq(before, c.position()) <= horizSq(before, flat) + 1.0E-6) {
                c.setPos(flat);               // step didn't help: keep the plain result and its flags
                c.setOnGround(flatGround);
                c.verticalCollision = flatVertical;
                c.horizontalCollision = true;
            }
        }

        c.setPos(c.getX(), c.getY(), c.getZ()); // back to the full-height box for everything outside the move

        // a blocked axis loses its speed, like vanilla
        Vec3 moved = c.position().subtract(before);
        if (Math.abs(moved.x) < Math.abs(v.x) - 1.0E-6) v = new Vec3(0, v.y, v.z);
        if (Math.abs(moved.z) < Math.abs(v.z) - 1.0E-6) v = new Vec3(v.x, v.y, 0);
        if (c.verticalCollision) vy = 0;

        // friction / drag / gravity for next tick (applied after the move, like vanilla)
        v = v.scale(drag);
        if (inLiquid) {
            if (!swimming) vy = vy * 0.8 - 0.02;
        } else {
            vy = (vy - GRAVITY) * 0.98;
        }
        if (v.lengthSqr() < 1.0E-8) v = Vec3.ZERO;
        ghostH = new Vec3(v.x, 0, v.z);
        ghostVy = vy;

        // safety nets: never walk off into unloaded chunks, never fall forever
        if (!mc.level.hasChunkAt(c.blockPosition())) {
            c.setPos(start);
            ghostH = Vec3.ZERO;
            ghostVy = 0;
            fallDistance = 0;
        } else if (owner != null && c.getY() < owner.getY() - 300) {
            c.setPos(owner.getX(), owner.getY(), owner.getZ());
            c.xo = c.getX(); c.yo = c.getY(); c.zo = c.getZ();
            ghostH = Vec3.ZERO;
            ghostVy = 0;
            fallDistance = 0;
        }

        Vec3 net = c.position().subtract(start);

        // vanilla movement hunger: 0.1 per metre sprinting on land, 0.01 per metre in water
        if (superLife) {
            double dist = Math.sqrt(net.x * net.x + net.z * net.z);
            if (inLiquid) superExhaustion += (float) (0.01 * dist);
            else if (c.onGround() && sprinting) superExhaustion += (float) (0.1 * dist);
        }

        // fall damage (vanilla rule: ceil(distance - 3) when you land; water cancels it)
        if (inLiquid) {
            fallDistance = 0;
        } else if (!c.onGround()) {
            if (net.y < 0) fallDistance -= net.y;
        } else {
            if (superLife && fallDistance > 3.0) hurt(mc, Math.ceil(fallDistance - 3.0));
            fallDistance = 0;
        }
        stepX = net.x;
        stepZ = net.z;
        velocity = new Vec3(ghostH.x, ghostVy, ghostH.z); // lets the HUD show a speed
    }

    /**
     * Second Chance hunger, following vanilla's FoodData rules: exhaustion above 4 uses up saturation first, then
     * food. At full food with saturation you heal fast; at 18+ food you heal 1 every 4 seconds (costing 6
     * exhaustion); at 0 food you starve (1 damage every 4 seconds, limited by difficulty). Peaceful keeps you fed.
     */
    private static void tickSuperHunger(Minecraft mc) {
        if (!superLife || mc.level == null || camera == null) return;
        hungerTick++;
        Difficulty difficulty = mc.level.getDifficulty();

        if (superExhaustion > 4.0F) {
            superExhaustion -= 4.0F;
            if (superSaturation > 0.0F) {
                superSaturation = Math.max(superSaturation - 1.0F, 0.0F);
            } else if (difficulty != Difficulty.PEACEFUL) {
                superFood = Math.max(superFood - 1, 0);
            }
        }

        if (difficulty == Difficulty.PEACEFUL) {
            if (superHealth < SUPER_MAX_HEALTH && hungerTick % 20 == 0) {
                superHealth = Math.min(SUPER_MAX_HEALTH, superHealth + 1.0);
            }
            if (superFood < 20 && hungerTick % 10 == 0) superFood++;
            regenTick = 0;
            return;
        }

        boolean hurtState = superHealth < SUPER_MAX_HEALTH;
        if (superSaturation > 0.0F && hurtState && superFood >= 20) {
            if (++regenTick >= 10) {
                float amount = Math.min(superSaturation, 6.0F);
                superHealth = Math.min(SUPER_MAX_HEALTH, superHealth + amount / 6.0);
                superExhaustion += amount;
                regenTick = 0;
            }
        } else if (superFood >= 18 && hurtState) {
            if (++regenTick >= 80) {
                superHealth = Math.min(SUPER_MAX_HEALTH, superHealth + 1.0);
                superExhaustion += 6.0F;
                regenTick = 0;
            }
        } else if (superFood <= 0) {
            if (++regenTick >= 80) {
                if (superHealth > 10.0 || difficulty == Difficulty.HARD
                        || (difficulty == Difficulty.NORMAL && superHealth > 1.0)) {
                    hurt(mc, 1.0);
                }
                regenTick = 0;
            }
        } else {
            regenTick = 0;
        }
    }

    // ---- damage from other living things (arrows, sword swings, ...), judged on your client -----------

    private static double projectileDamage(Projectile p, double speed) {
        String n = p.getClass().getSimpleName();
        if (n.contains("Trident")) return 8.0;
        if (n.contains("WitherSkull")) return 8.0;
        if (n.contains("Fireball")) return 6.0;
        if (n.contains("ShulkerBullet")) return 4.0;
        if (n.contains("Arrow")) return speed > 0.6 ? Math.ceil(speed * 2.0) : 0; // arrows stuck in blocks do nothing
        return 0; // snowballs, eggs, etc. don't hurt
    }

    /**
     * Vanilla melee damage for whatever just swung at you. The client does not know other entities' real attack
     * damage (the attribute is not sent to clients, and equipment bonuses are only applied by the server), so it
     * is rebuilt here the way vanilla does: the attacker's base attack damage plus the attack-damage modifiers of
     * the item in their main hand (a diamond sword is 7, an axe 9, a fist 1, ...). Mobs hit harder or softer
     * depending on difficulty, like in vanilla. Not included: enchantments, potion effects, critical hits and
     * the weapon-cooldown scaling, none of which the client can see.
     */
    private static double meleeDamage(Minecraft mc, LivingEntity attacker) {
        try {
            double base = attacker.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                    ? attacker.getAttributeBaseValue(Attributes.ATTACK_DAMAGE) : 1.0;
            double[] add = {0.0};
            double[] multiplyBase = {0.0};
            double[] multiplyTotal = {1.0};
            ItemStack weapon = attacker.getMainHandItem();
            if (!weapon.isEmpty()) {
                weapon.forEachModifier(EquipmentSlot.MAINHAND, (attribute, modifier) -> {
                    if (!attribute.equals(Attributes.ATTACK_DAMAGE)) return;
                    switch (modifier.operation()) {
                        case ADD_VALUE -> add[0] += modifier.amount();
                        case ADD_MULTIPLIED_BASE -> multiplyBase[0] += modifier.amount();
                        case ADD_MULTIPLIED_TOTAL -> multiplyTotal[0] *= 1.0 + modifier.amount();
                    }
                });
            }
            double damage = (base + add[0]) * (1.0 + multiplyBase[0]) * multiplyTotal[0];
            return scaleByDifficulty(mc, Math.max(0.0, damage), attacker);
        } catch (RuntimeException ignored) {
            // fall through to the default
        }
        return scaleByDifficulty(mc, 2.0, attacker);
    }

    /** Vanilla scales damage caused by living non-players with difficulty: Easy about half (+1), Hard 1.5x. */
    private static double scaleByDifficulty(Minecraft mc, double amount, Entity cause) {
        if (mc.level == null || !(cause instanceof LivingEntity) || cause instanceof Player) return amount;
        Difficulty difficulty = mc.level.getDifficulty();
        if (difficulty == Difficulty.PEACEFUL) return 0.0;
        if (difficulty == Difficulty.EASY) return Math.min(amount / 2.0 + 1.0, amount);
        if (difficulty == Difficulty.HARD) return amount * 3.0 / 2.0;
        return amount;
    }

    /** Applies client-side drowning and fire/lava damage to the reanimated body. */
    private static void tickEnvironmentalDamage(Minecraft mc, Marker c) {
        BlockPos feetPos = BlockPos.containing(c.getX(), c.getY() + 0.1, c.getZ());
        BlockPos bodyPos = BlockPos.containing(c.getX(), c.getY() + 0.9, c.getZ());

        // Drowning, with vanilla's numbers: 300 air, -1 per tick with the eyes in water, +4 per tick otherwise,
        // and at -20 the air resets to 0 and you take 2 damage (once a second while you keep drowning).
        double eyeY = puppet != null ? puppet.getEyeY() : c.getY() + 1.62;
        BlockPos eyePos = BlockPos.containing(c.getX(), eyeY, c.getZ());
        var eyeFluid = mc.level.getFluidState(eyePos);
        headUnderwater = eyeFluid.is(FluidTags.WATER) && eyeY < eyePos.getY() + eyeFluid.getHeight(mc.level, eyePos);
        if (headUnderwater) {
            superAir--;
            if (superAir <= -20) {
                superAir = 0;
                hurt(mc, 2.0);
            }
        } else if (superAir < AIR_MAX) {
            superAir = Math.min(AIR_MAX, superAir + 4);
        }

        boolean touchingFire = mc.level.getBlockState(feetPos).is(BlockTags.FIRE)
                || mc.level.getBlockState(bodyPos).is(BlockTags.FIRE)
                || mc.level.getFluidState(feetPos).is(FluidTags.LAVA)
                || mc.level.getFluidState(bodyPos).is(FluidTags.LAVA);
        if (touchingFire) {
            if (fireDamageTicks <= 0 && invulnTicks <= 0) {
                hurt(mc, 2.0);
                fireDamageTicks = 20;
            } else if (fireDamageTicks > 0) {
                fireDamageTicks--;
            }
        } else {
            fireDamageTicks = 0;
        }
    }

    /** Checks whether projectiles or swinging mobs/players hit the ghost this tick. One hit per tick, with grace time. */
    private static void tickSuperLife(Minecraft mc, Marker c) {
        if (invulnTicks > 0) invulnTicks--;
        if (!superLife || mc.level == null) return;
        tickEnvironmentalDamage(mc, c);
        tickSuperHunger(mc);
        if (++editTick % 10 == 0) reapplyLocalEdits(mc);
        if (!superLife || invulnTicks > 0) return;
        if (hitProjectiles.size() > 512) hitProjectiles.clear();

        AABB box = c.getBoundingBox();
        Vec3 body = c.position().add(0, 0.9, 0);
        for (Entity e : mc.level.getEntities((Entity) null, box.inflate(4.0))) {
            if (e == puppet || e == mc.player || e == c) continue;

            if (e instanceof Projectile pr) {
                if (pr.getOwner() == mc.player || hitProjectiles.contains(pr.getId())) continue;
                if (!box.inflate(0.3).intersects(pr.getBoundingBox())) continue;
                double dmg = projectileDamage(pr, pr.getDeltaMovement().length());
                if (dmg <= 0) continue;
                hitProjectiles.add(pr.getId());
                hurt(mc, scaleByDifficulty(mc, dmg, pr.getOwner()));
                return;
            }

            // melee: someone starts a swing while you are within reach and in front of them
            if (e instanceof LivingEntity le && le.swinging && le.swingTime == 0) {
                Vec3 eye = le.getEyePosition();
                if (eye.distanceTo(body) > 3.5) continue;
                Vec3 to = body.subtract(eye);
                if (to.lengthSqr() < 1.0E-6 || le.getLookAngle().dot(to.normalize()) < 0.6) continue;
                hurt(mc, meleeDamage(mc, le));
                return;
            }
        }
    }

    /**
     * Second Chance tools, purely local: hold left click to mine the block you look at (vanilla break time for the
     * item in hand), right click to place a block item. Only YOUR screen changes; the server never hears of it,
     * so blocks you break or place come back if the server resends that spot.
     */
    /** Pours a water or lava source where you point (local only) and leaves you an empty bucket. */
    private static void pourBucket(Minecraft mc, BlockHitResult hit, ItemStack held) {
        BlockPos clickedPos = hit.getBlockPos();
        BlockPos at = mc.level.getBlockState(clickedPos).canBeReplaced() ? clickedPos : clickedPos.relative(hit.getDirection());
        BlockState existing = mc.level.getBlockState(at);
        if (!existing.isAir() && !existing.canBeReplaced()) return;
        BlockState fluid = (held.is(Items.WATER_BUCKET) ? Blocks.WATER : Blocks.LAVA).defaultBlockState();
        mc.level.setBlock(at, fluid, 11);
        recordEdit(at, fluid);
        int slot = owner.getInventory().getSelectedSlot();
        ItemStack empty = new ItemStack(Items.BUCKET);
        owner.getInventory().setItem(slot, empty);
        if (puppet != null) puppet.getInventory().setItem(slot, empty);
        placeCooldown = 4;
        startSwing();
    }

    private static void tickTools(Minecraft mc, Marker c, boolean useClicked) {
        if (miningCooldown > 0) miningCooldown--;
        if (placeCooldown > 0) placeCooldown--;
        if (!superLife || !gearGiven || owner == null || puppet == null || mc.level == null || mc.gui.screen() != null) {
            cancelMining(mc);
            attackWasDown = false;
            return;
        }

        HitResult result = mc.hitResult;
        BlockHitResult hit = (result instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK) ? b : null;
        ItemStack held = owner.getMainHandItem();

        // right click (or hold): place the block in hand
        boolean useDown = mc.options.keyUse.isDown();
        if (hit != null && (useClicked || (useDown && placeCooldown == 0))
                && (held.is(Items.WATER_BUCKET) || held.is(Items.LAVA_BUCKET))) {
            pourBucket(mc, hit, held);
        }
        if (hit != null && (useClicked || (useDown && placeCooldown == 0))
                && !held.isEmpty() && held.getItem() instanceof BlockItem blockItem) {
            BlockPlaceContext context = new BlockPlaceContext(owner, InteractionHand.MAIN_HAND, held, hit);
            if (context.canPlace()) {
                BlockState state = blockItem.getBlock().getStateForPlacement(context);
                BlockPos at = context.getClickedPos();
                boolean insideYou = state != null && !state.getCollisionShape(mc.level, at).isEmpty()
                        && c.getBoundingBox().intersects(new AABB(at));
                if (state != null && !insideYou) {
                    mc.level.setBlock(at, state, 11);
                    recordEdit(at, state);
                    held.shrink(1);
                    placeCooldown = 4;
                    startSwing();
                }
            }
        }

        // empty bucket: scoop up a water or lava source (including ones you placed yourself)
        if ((useClicked || (useDown && placeCooldown == 0)) && held.is(Items.BUCKET)) {
            scoopBucket(mc, held);
        }

        // everything else: place a client-side ghost copy where you aim (Shift+right click for ANY item)
        if (useClicked && !held.isEmpty() && ItemSupport.ghostPlaceable(held.getItem(), ghostCrouching)) {
            placeGhost(mc, held);
        }

        // food: hold right click for 32 ticks to eat it (refills Super Death hunger, uses up the local copy)
        tickEating(mc, held, hit != null, useDown);

        // tell the player why an item does nothing instead of failing silently
        if (useClicked && !held.isEmpty()) {
            String reason = ItemSupport.serverReason(held.getItem());
            if (reason != null) {
                mc.gui.hud.setOverlayMessage(Component.literal(held.getHoverName().getString() + ": " + reason), false);
            }
        }

        // left click (hold): mine. A fresh click on one of your ghosts picks it back up instead.
        boolean attackDown = mc.options.keyAttack.isDown();
        boolean attackPressed = attackDown && !attackWasDown;
        attackWasDown = attackDown;
        if (attackPressed && pickUpGhost(mc)) {
            cancelMining(mc);
            return;
        }
        if (hit == null || !attackDown) {
            cancelMining(mc);
            return;
        }
        if (miningCooldown > 0) return;

        BlockPos pos = hit.getBlockPos();
        BlockState target = mc.level.getBlockState(pos);
        float hardness = target.isAir() ? -1.0F : target.getDestroySpeed(mc.level, pos);
        if (hardness < 0.0F) { // air, bedrock and the like
            cancelMining(mc);
            return;
        }
        if (!pos.equals(miningPos)) {
            cancelMining(mc);
            miningPos = pos;
        }

        float speed = held.getDestroySpeed(target);
        boolean canHarvest = !target.requiresCorrectToolForDrops() || held.isCorrectToolForDrops(target);
        if (!c.onGround()) speed /= 5.0F;                              // vanilla: slower in the air
        if (headUnderwater) speed /= 5.0F;                              // and with your head underwater
        miningProgress += hardness == 0.0F ? 1.0F : speed / hardness / (canHarvest ? 30.0F : 100.0F);

        if (miningProgress >= 1.0F) {
            mc.level.destroyBlockProgress(PUPPET_ID, pos, -1);
            mc.level.destroyBlock(pos, false); // local only; plays the break sound and particles
            recordEdit(pos, mc.level.getBlockState(pos));
            miningPos = null;
            miningProgress = 0;
            miningCooldown = 5;
        } else {
            mc.level.destroyBlockProgress(PUPPET_ID, pos, Math.min(9, (int) (miningProgress * 10.0F)));
        }
    }

    /**
     * Ghost items: right click places a client-side copy of the item where you aim, visible only on your screen.
     * Boats, rafts, minecarts, armor stands, end crystals and spawn eggs are drawn as the real entity (a boat on
     * the water, the mob from the egg); everything else (potions, ingots, books, ...) is drawn as an item drop.
     * Nothing is sent to the server. Punch a ghost to pick it back up; they all vanish when Second Chance ends.
     */
    private static void placeGhost(Minecraft mc, ItemStack held) {
        Vec3 eye = puppet.getEyePosition();
        Vec3 end = eye.add(puppet.getViewVector(1.0F).scale(4.5));
        // look through water as well, so a boat can be placed on the surface
        BlockHitResult surface = mc.level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.ANY, puppet));
        if (surface.getType() != HitResult.Type.BLOCK) return;

        String name = held.getHoverName().getString();
        Vec3 spot = surface.getLocation();
        var face = surface.getDirection();

        Entity ghost = null;
        String entityId = ItemSupport.entityIdFor(held.getItem());
        if (entityId != null) ghost = createGhostEntity(mc, entityId);
        if (ghost != null) {
            ghost.setPos(spot.x + face.getStepX() * 0.05, spot.y + face.getStepY() * 0.05, spot.z + face.getStepZ() * 0.05);
            ghost.setYRot(puppet.getYRot());
            if (ghost instanceof LivingEntity living) {
                living.yHeadRot = puppet.getYRot();
                living.yBodyRot = puppet.getYRot();
            }
        } else {
            ItemEntity drop = new ItemEntity(mc.level,
                    spot.x + face.getStepX() * 0.3, spot.y + face.getStepY() * 0.3, spot.z + face.getStepZ() * 0.3,
                    held.copyWithCount(1));
            drop.setNeverPickUp();
            drop.setDeltaMovement(Vec3.ZERO);
            ghost = drop;
        }
        ghost.setGlowingTag(true); // white outline: reads as a ghost
        int id = GHOST_ID_BASE - (ghostSeq++ % 100000);
        ghost.setId(id);
        mc.level.addEntity(ghost);
        ghostIds.add(id);
        ghostItems.put(id, held.copyWithCount(1));
        while (ghostIds.size() > MAX_GHOSTS) {
            int oldest = ghostIds.poll();
            ghostItems.remove(oldest);
            mc.level.removeEntity(oldest, Entity.RemovalReason.DISCARDED);
        }

        held.shrink(1);
        placeCooldown = 8;
        startSwing();
        mc.gui.hud.setOverlayMessage(Component.literal(name + ": placed as a ghost (only you can see it; punch it to pick it up)"), false);
    }

    /** Creates the real entity for a ghost (a boat, a mob, ...) without adding it anywhere; null if it cannot be made. */
    private static Entity createGhostEntity(Minecraft mc, String entityId) {
        try {
            Identifier key = Identifier.fromNamespaceAndPath("minecraft", entityId);
            if (!BuiltInRegistries.ENTITY_TYPE.containsKey(key)) return null;
            EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.getValue(key);
            return type.create(mc.level, EntitySpawnReason.SPAWN_ITEM_USE);
        } catch (RuntimeException e) {
            return null; // fall back to the item drop
        }
    }

    /** Left click on a ghost you placed: remove it and give the item back. Returns true if one was picked up. */
    private static boolean pickUpGhost(Minecraft mc) {
        if (ghostIds.isEmpty()) return false;
        Vec3 eye = puppet.getEyePosition();
        Vec3 end = eye.add(puppet.getViewVector(1.0F).scale(4.5));
        Integer bestId = null;
        double best = Double.MAX_VALUE;
        for (int id : ghostIds) {
            Entity e = mc.level.getEntity(id);
            if (e == null) continue;
            var hit = e.getBoundingBox().inflate(0.25).clip(eye, end);
            if (hit.isPresent()) {
                double d = eye.distanceToSqr(hit.get());
                if (d < best) { best = d; bestId = id; }
            }
        }
        if (bestId == null) return false;
        ghostIds.remove(bestId);
        ItemStack back = ghostItems.remove(bestId);
        mc.level.removeEntity(bestId, Entity.RemovalReason.DISCARDED);
        if (back != null) giveBack(back);
        startSwing();
        return true;
    }

    /** Right click with an empty bucket: turn a water or lava source block into a full bucket (local only). */
    private static void scoopBucket(Minecraft mc, ItemStack held) {
        Vec3 eye = puppet.getEyePosition();
        Vec3 end = eye.add(puppet.getViewVector(1.0F).scale(4.5));
        BlockHitResult hit = mc.level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.SOURCE_ONLY, puppet));
        if (hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = hit.getBlockPos();
        BlockState state = mc.level.getBlockState(pos);
        boolean water = state.is(Blocks.WATER);
        if (!(water || state.is(Blocks.LAVA)) || !state.getFluidState().isSource()) return;

        BlockState air = Blocks.AIR.defaultBlockState();
        mc.level.setBlock(pos, air, 11);
        recordEdit(pos, air); // so the server resending the area does not put the fluid back

        ItemStack filled = new ItemStack(water ? Items.WATER_BUCKET : Items.LAVA_BUCKET);
        int slot = owner.getInventory().getSelectedSlot();
        if (held.getCount() <= 1) {
            owner.getInventory().setItem(slot, filled);
            if (puppet != null) puppet.getInventory().setItem(slot, filled);
        } else {
            held.shrink(1);
            giveBack(filled);
        }
        placeCooldown = 4;
        startSwing();
    }

    /** Puts an item into your local inventory and mirrors the change onto the ghost body's hotbar copy. */
    private static void giveBack(ItemStack stack) {
        if (owner == null) return;
        owner.getInventory().add(stack);
        if (puppet == null) return;
        var from = owner.getInventory();
        var to = puppet.getInventory();
        for (int i = 0; i < 36 && i < from.getContainerSize(); i++) to.setItem(i, from.getItem(i));
    }

    private static void clearGhosts(Minecraft mc) {
        if (mc.level != null) {
            for (int id : ghostIds) mc.level.removeEntity(id, Entity.RemovalReason.DISCARDED);
        }
        ghostIds.clear();
        ghostItems.clear();
    }

    private static boolean tickErrorLogged;

    /**
     * Last line of defence: if anything in the per-tick code throws, log it once and leave freecam cleanly instead
     * of letting the exception crash the game (or repeat every tick).
     */
    private static void failSafe(Minecraft mc, RuntimeException e) {
        if (!tickErrorLogged) {
            tickErrorLogged = true;
            System.err.println("[deathcam] unexpected error, leaving freecam: " + e);
            e.printStackTrace();
        }
        try {
            stop(mc);
        } catch (RuntimeException ignored) {
            // nothing more we can do
        }
    }

    private static void tickEating(Minecraft mc, ItemStack held, boolean aimingAtBlock, boolean useDown) {
        var food = held.isEmpty() ? null : held.get(DataComponents.FOOD);
        // blocks that are also food (sweet berries) are planted when you aim at a block, eaten otherwise
        boolean placesInstead = held.getItem() instanceof BlockItem && aimingAtBlock;
        if (food == null || !useDown || placesInstead || (superFood >= 20 && !food.canAlwaysEat())) {
            eatTicks = 0;
            return;
        }
        eatTicks++;
        if (eatTicks % 5 == 1) startSwing(); // arm movement as feedback
        if (eatTicks >= 32) {
            superFood = Math.min(20, superFood + food.nutrition());
            superSaturation = Math.min((float) superFood, superSaturation + food.saturation());
            held.shrink(1);
            eatTicks = 0;
        }
    }

    /** Optional features must never be able to take the game down: swallow and log (once) anything they throw. */
    private static void logToolError(RuntimeException e) {
        if (toolErrorLogged) return;
        toolErrorLogged = true;
        System.err.println("[deathcam] a Super Death tool action failed and was skipped: " + e);
    }

    private static void tick(Minecraft mc) {
        LostItems.tick(mc);

        // back among the living (or left the world): the next death screen is a normal one again
        if (diedAgain && (mc.player == null || !mc.player.isDeadOrDying())) diedAgain = false;

        // the second chance ran out: leave freecam and go back to the death screen
        if (diedAgainPending) {
            diedAgainPending = false;
            if (camera != null) {
                diedAgain = true; // must be set before the screen is created
                exit(mc, true);
                return;
            }
        }

        // Lost-items key (F12 by default): works in freecam or after respawning; pressing it again closes the screen.
        while (lostItemsKey.consumeClick()) {
            if (mc.player != null && mc.gui.screen() == null) {
                mc.gui.setScreen(new LostItemsScreen(null));
            } else if (mc.gui.screen() instanceof LostItemsScreen lost) {
                lost.onClose();
            }
        }

        if (camera == null) {
            // Throw away menu-key presses made outside freecam, or the menu would pop open the moment you enter it.
            while (menuKey.consumeClick()) { /* discard */ }
            return;
        }

        // respawned, died elsewhere, changed dimension, or left the world
        if (mc.player == null || mc.player != owner || !mc.player.isDeadOrDying() || camera.level() != mc.level) {
            stop(mc);
            return;
        }

        while (menuKey.consumeClick()) {
            if (mc.gui.screen() == null) mc.gui.setScreen(new DeathCamSettingsScreen());
            else if (mc.gui.screen() instanceof DeathCamSettingsScreen) mc.gui.setScreen(null);
        }

        // E returns to the death screen. Presses made while a menu was open are discarded so closing
        // a menu can't kick you out of freecam afterwards.
        boolean leave = false;
        while (mc.options.keyInventory.consumeClick()) leave = true;
        if (leave && mc.gui.screen() == null) { exit(mc, true); return; }

        // Left click = swing the fist. We consume the clicks so vanilla never tries to attack/mine as a dead player.
        boolean clicked = false;
        while (mc.options.keyAttack.consumeClick()) clicked = true;
        if (mc.gui.screen() == null && (clicked || mc.options.keyAttack.isDown())) startSwing();
        tickSwing();

        // Right click: consumed here so vanilla never sends "use item / place block" packets for a dead player.
        boolean useClicked = false;
        while (mc.options.keyUse.consumeClick()) useClicked = true;

        mc.smartCull = false; // keep it off even if something else flipped it back
        if (hurtTicks > 0) hurtTicks--;

        Marker c = camera;
        c.xo = c.getX(); c.yo = c.getY(); c.zo = c.getZ();
        c.xRotO = c.getXRot(); c.yRotO = c.getYRot();

        if (ghostMode) {
            if (puppet != null) {
                c.setYRot(puppet.getYRot());
                c.setXRot(puppet.getXRot());
                if (gearGiven && owner != null) { // block placement reads the player's facing
                    owner.setYRot(puppet.getYRot());
                    owner.setXRot(puppet.getXRot());
                    neutralizeHandSway();
                }
            }
            tickGhost(mc, c, mc.gui.screen() == null);
            try {
                tickSuperLife(mc, c);
                tickTools(mc, c, useClicked);
            } catch (RuntimeException e) {
                logToolError(e);
            }
        } else if (mc.gui.screen() == null) {
            double f = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
            double s = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
            double v = (mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0);

            double yaw = Math.toRadians(c.getYRot());
            Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
            Vec3 move = c.getLookAngle().scale(f).add(right.scale(s)).add(0, v, 0);
            double speed = DeathCamConfig.speed * (mc.options.keySprint.isDown() ? SPRINT_MULT : 1.0);
            Vec3 targetVelocity = move.lengthSqr() > 1.0E-6
                    ? move.normalize().scale(speed)
                    : Vec3.ZERO;

            if (DeathCamConfig.smoothMovement) {
                velocity = velocity.add(targetVelocity.subtract(velocity).scale(SMOOTHING));
                if (velocity.lengthSqr() < 0.00001 && targetVelocity.lengthSqr() < 0.00001) velocity = Vec3.ZERO;
            } else {
                velocity = targetVelocity;
            }
            c.setPos(c.position().add(velocity));
        } else {
            velocity = Vec3.ZERO;
        }

        // The readout shows real movement. (It used to show the internal velocity, which includes gravity pushing
        // a ghost into the floor every tick, so a ghost standing still read about 0.08 instead of 0.)
        movedSpeed = c.position().distanceTo(new Vec3(c.xo, c.yo, c.zo));
    }
}
