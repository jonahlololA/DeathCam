package dev.deathcam;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Read-only view of what you were carrying when you last died. */
public final class LostItemsScreen extends Screen {
	private record Slot(int index, int x, int y) {}

	private final Screen parent;
	private final List<Slot> slots = new ArrayList<>();
	private int left, top, panelBottom;

	public LostItemsScreen(Screen parent) {
		super(Component.literal("Lost Items"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		slots.clear();
		left = this.width / 2 - 81;
		top = Math.max(4, this.height / 2 - 85);

		// Inventory indices: 0-8 hotbar, 9-35 main, 36 boots, 37 legs, 38 chest, 39 helmet, 40 offhand
		int armorY = top + 16;
		int[] armor = {39, 38, 37, 36, 40};
		for (int i = 0; i < armor.length; i++) slots.add(new Slot(armor[i], left + i * 18, armorY));

		int mainY = armorY + 26;
		for (int row = 0; row < 3; row++)
			for (int col = 0; col < 9; col++)
				slots.add(new Slot(9 + row * 9 + col, left + col * 18, mainY + row * 18));

		int hotbarY = mainY + 3 * 18 + 4;
		for (int col = 0; col < 9; col++) slots.add(new Slot(col, left + col * 18, hotbarY));

		panelBottom = hotbarY + 18 + 24;
		this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
				.bounds(this.width / 2 - 50, panelBottom + 6, 100, 20).build());
	}

	private static ItemStack stackAt(int index) {
		ItemStack[] g = LostItems.lost();
		if (g == null || index < 0 || index >= g.length || g[index] == null) return ItemStack.EMPTY;
		return g[index];
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		super.extractRenderState(g, mouseX, mouseY, partialTick);

		g.fill(left - 8, top - 6, left + 162 + 8, panelBottom, 0xC0101018);
		g.text(this.font, "Items you lost", left, top + 2, 0xFFA8C0FF, true);

		ItemStack hovered = ItemStack.EMPTY;
		for (Slot s : slots) {
			boolean over = mouseX >= s.x() && mouseX < s.x() + 18 && mouseY >= s.y() && mouseY < s.y() + 18;
			ItemStack st = stackAt(s.index());
			g.fill(s.x(), s.y(), s.x() + 18, s.y() + 18, over ? 0xFF7A8AD0 : 0xFF3A4570);
			g.fill(s.x() + 1, s.y() + 1, s.x() + 17, s.y() + 17, 0xFF141824);
			if (!st.isEmpty()) {
				g.item(st, s.x() + 1, s.y() + 1);
				g.itemDecorations(this.font, st, s.x() + 1, s.y() + 1);
				if (over) hovered = st;
			}
		}

		String footer;
		if (LostItems.lost() == null) {
			footer = "Nothing recorded yet - die first.";
		} else if (!hovered.isEmpty()) {
			footer = hovered.getHoverName().getString() + (hovered.getCount() > 1 ? " x" + hovered.getCount() : "");
		} else {
			int n = LostItems.count(LostItems.lost());
			footer = n == 0 ? "You had nothing on you." : n + " stack" + (n == 1 ? "" : "s") + " lost";
		}
		g.text(this.font, footer, left, panelBottom - 14, 0xFFFFFFFF, true);
	}

	@Override
	public boolean shouldCloseOnEsc() { return true; }

	@Override
	public void onClose() {
		Minecraft.getInstance().gui.setScreen(parent);
	}
}
