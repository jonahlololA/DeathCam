package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.contextualbar.ExperienceBar;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla XP bar while the local player is dead, except during Second Chance. Always on; no setting. */
@Mixin(ExperienceBar.class)
public abstract class ExperienceBarMixin {
	@Inject(method = "extractBackground", at = @At("HEAD"), cancellable = true)
	private void deathcam$hideBackgroundWhenDead(CallbackInfo ci) {
		if (deathcam$isPlayerDead()) ci.cancel();
	}

	@Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true)
	private void deathcam$hideBarWhenDead(CallbackInfo ci) {
		if (deathcam$isPlayerDead()) ci.cancel();
	}

	private static boolean deathcam$isPlayerDead() {
		Minecraft minecraft = Minecraft.getInstance();
		return minecraft.player != null && minecraft.player.isDeadOrDying()
			&& !(DeathCam.isGhost() && DeathCam.isSuperLife());
	}
}
