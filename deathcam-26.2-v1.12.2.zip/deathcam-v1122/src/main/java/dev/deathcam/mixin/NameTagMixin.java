package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public abstract class NameTagMixin {
	// Keep the dead original player hidden; the reanimated copy displays the real username.
	@Inject(method = "shouldShowName", at = @At("HEAD"), cancellable = true, require = 0)
	private void deathcam$hideGhostName(LivingEntity entity, double distanceSq, CallbackInfoReturnable<Boolean> cir) {
		if (DeathCam.isGhost() && entity == Minecraft.getInstance().player) {
			cir.setReturnValue(false);
		}
	}
}
