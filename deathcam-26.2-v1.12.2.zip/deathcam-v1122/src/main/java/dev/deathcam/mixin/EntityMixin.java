package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
	// Mouse look calls player.turn(); send it to the freecam / ghost body instead of the corpse.
	@Inject(method = "turn", at = @At("HEAD"), cancellable = true)
	private void deathcam$turn(double yRot, double xRot, CallbackInfo ci) {
		if (DeathCam.isActive() && (Object) this == Minecraft.getInstance().player) {
			Entity look = DeathCam.lookEntity();
			float before = look.getYRot();
			look.turn(yRot, xRot);
			DeathCam.syncHeadYaw(look, look.getYRot() - before);
			ci.cancel();
		}
	}

	// The ghost body's glow outline is red instead of the default white.
	@Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
	private void deathcam$ghostOutlineColor(CallbackInfoReturnable<Integer> cir) {
		if (DeathCam.puppet() != null && (Object) this == DeathCam.puppet()) {
			cir.setReturnValue(0xFFFF2020);
		}
	}
}
