package dev.deathcam.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.deathcam.DeathCam;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Gui.class)
public abstract class GuiMixin {
	// setScreen(null) force-opens the death screen while dead; skip that during freecam.
	@WrapOperation(method = "setScreen",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;isDeadOrDying()Z"))
	private boolean deathcam$allowNoScreen(LocalPlayer player, Operation<Boolean> original) {
		return !DeathCam.isActive() && original.call(player);
	}
}
