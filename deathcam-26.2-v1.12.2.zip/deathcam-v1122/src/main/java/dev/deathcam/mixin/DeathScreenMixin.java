package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import dev.deathcam.LostItemsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DeathScreen.class)
public abstract class DeathScreenMixin extends Screen {
	protected DeathScreenMixin(Component title) { super(title); }

	// After a second chance runs out the title reads "You died, again." instead of "You died!".
	@ModifyArg(method = "<init>",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;<init>(Lnet/minecraft/network/chat/Component;)V"),
		index = 0, require = 0)
	private static Component deathcam$diedAgainTitle(Component original) {
		return DeathCam.diedAgain() ? Component.literal("You died, again.") : original;
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void deathcam$addButton(CallbackInfo ci) {
		this.addRenderableWidget(Button.builder(Component.literal("Freecam"),
				b -> DeathCam.enter(Minecraft.getInstance()))
			.bounds(this.width / 2 - 100, this.height / 4 + 120, 200, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("Lost items"),
				b -> Minecraft.getInstance().gui.setScreen(new LostItemsScreen(this)))
			.bounds(this.width / 2 - 100, this.height / 4 + 144, 200, 20).build());
	}
}
