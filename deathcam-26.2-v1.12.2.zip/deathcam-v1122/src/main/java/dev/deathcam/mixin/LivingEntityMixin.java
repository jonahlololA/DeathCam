package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
	// While in freecam, the dead player's swing progress comes from DeathCam instead of the (frozen) entity state.
	@Inject(method = "getAttackAnim", at = @At("HEAD"), cancellable = true)
	private void deathcam$freecamSwing(float partialTick, CallbackInfoReturnable<Float> cir) {
		if (DeathCam.isActive() && (Object) this == DeathCam.owner()) {
			cir.setReturnValue(DeathCam.attackAnim(partialTick));
		}
	}

	// The ghost body is moved from outside its own tick, so vanilla's walk animation (which compares the
	// position with last tick's) would always see "no movement". Feed it the ghost's real movement instead.
	@Inject(method = "calculateEntityAnimation", at = @At("HEAD"))
	private void deathcam$ghostWalkAnimation(boolean includeHeight, CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (DeathCam.puppet() != null && self == DeathCam.puppet()) {
			self.xo = self.getX() - DeathCam.stepX();
			self.zo = self.getZ() - DeathCam.stepZ();
		}
	}
	// The puppet is moved externally, so vanilla's per-tick swim interpolation does not reliably
	// advance. Feed the player renderer a full swim amount while our ghost is sprint-swimming.
	@Inject(method = "getSwimAmount", at = @At("HEAD"), cancellable = true)
	private void deathcam$ghostSwimAnimation(float partialTick, CallbackInfoReturnable<Float> cir) {
		if ((Object) this == DeathCam.puppet() && DeathCam.isSwimming()) {
			cir.setReturnValue(1.0F);
		}
	}

}
