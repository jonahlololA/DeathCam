package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
	// The ghost body has a made-up UUID, so the game cannot look its skin up by itself: borrow the real player's skin.
	@SuppressWarnings({"rawtypes", "unchecked"})
	@Inject(method = "getSkin", at = @At("HEAD"), cancellable = true, require = 0)
	private void deathcam$borrowRealSkin(CallbackInfoReturnable cir) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null && DeathCam.puppet() != null && (Object) this == DeathCam.puppet()) {
			cir.setReturnValue(mc.player.getSkin());
		}
	}
}
