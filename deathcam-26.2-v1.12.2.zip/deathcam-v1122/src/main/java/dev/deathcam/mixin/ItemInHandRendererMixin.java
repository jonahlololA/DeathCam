package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.client.renderer.ItemInHandRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Keeps the dead player's first-person hands visible only while the hand-render
 * method is building this frame. The real equip-progress fields are restored
 * immediately afterward, so vanilla attack/swing animation remains untouched.
 */
@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {
    @Shadow private float mainHandHeight;
    @Shadow private float oMainHandHeight;
    @Shadow private float offHandHeight;
    @Shadow private float oOffHandHeight;

    @Unique private float deathcam$savedMainHandHeight;
    @Unique private float deathcam$savedOldMainHandHeight;
    @Unique private float deathcam$savedOffHandHeight;
    @Unique private float deathcam$savedOldOffHandHeight;
    @Unique private boolean deathcam$restoreAfterRender;

    @Inject(method = "submitHandsWithItems", at = @At("HEAD"))
    private void deathcam$showHandsForThisFrame(CallbackInfo ci) {
        deathcam$restoreAfterRender = DeathCam.isActive();
        if (!deathcam$restoreAfterRender) return;

        DeathCam.neutralizeHandSway(); // otherwise held items slide sideways as you turn (see DeathCam)

        deathcam$savedMainHandHeight = mainHandHeight;
        deathcam$savedOldMainHandHeight = oMainHandHeight;
        deathcam$savedOffHandHeight = offHandHeight;
        deathcam$savedOldOffHandHeight = oOffHandHeight;

        // Use fully equipped values only for this render pass. Swing progress
        // is still read from the player normally and therefore animates as usual.
        mainHandHeight = 1.0F;
        oMainHandHeight = 1.0F;
        offHandHeight = 1.0F;
        oOffHandHeight = 1.0F;
    }

    @Inject(method = "submitHandsWithItems", at = @At("RETURN"))
    private void deathcam$restoreHandStateAfterRender(CallbackInfo ci) {
        if (!deathcam$restoreAfterRender) return;

        mainHandHeight = deathcam$savedMainHandHeight;
        oMainHandHeight = deathcam$savedOldMainHandHeight;
        offHandHeight = deathcam$savedOffHandHeight;
        oOffHandHeight = deathcam$savedOldOffHandHeight;
        deathcam$restoreAfterRender = false;
    }
}
