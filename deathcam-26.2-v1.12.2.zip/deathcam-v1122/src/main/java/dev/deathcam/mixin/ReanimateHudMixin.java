package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.client.gui.Hud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While reanimated, vanilla's hearts, hunger bar and hotbar are all hidden. Vanilla draws those for the
 * camera entity's player data, which is unreliable for our client-only ghost body, so while Second Chance is on
 * DeathCamHud draws its own hearts, hunger, air bubbles and hotbar from the mod's own values instead.
 */
@Mixin(Hud.class)
public abstract class ReanimateHudMixin {
    @Inject(method = "extractHearts", at = @At("HEAD"), cancellable = true)
    private void deathcam$hideHeartsDuringReanimate(CallbackInfo ci) {
        if (DeathCam.isGhost()) {
            ci.cancel();
        }
    }

    @Inject(method = "extractFood", at = @At("HEAD"), cancellable = true)
    private void deathcam$hideVanillaFood(CallbackInfo ci) {
        if (DeathCam.isGhost()) {
            ci.cancel();
        }
    }

    // Only the hotbar itself. extractHotbarAndDecorations also draws the health/hunger/air bars.
    @Inject(method = "extractItemHotbar", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathcam$hideHotbarDuringReanimate(CallbackInfo ci) {
        if (DeathCam.isGhost()) {
            ci.cancel();
        }
    }
}
