package dev.deathcam.mixin;

import dev.deathcam.DeathCam;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
	// The old Entity.noCulling flag is gone in 26.2: tell the renderer never to frustum-cull the ghost body instead.
	@Inject(method = "affectedByCulling", at = @At("HEAD"), cancellable = true, require = 0)
	private void deathcam$neverCullGhost(Entity entity, CallbackInfoReturnable<Boolean> cir) {
		if (DeathCam.puppet() != null && entity == DeathCam.puppet()) {
			cir.setReturnValue(false);
		}
	}
}
