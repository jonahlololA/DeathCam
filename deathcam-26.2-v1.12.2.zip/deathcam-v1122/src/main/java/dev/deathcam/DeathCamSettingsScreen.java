package dev.deathcam;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

/** F10 settings menu for DeathCam. */
public final class DeathCamSettingsScreen extends Screen {
    private SpeedSlider speedSlider;
    private EditBox speedBox;
    private boolean updatingBox;
    private String lastValidText = "";

    private Button menuKeyButton;
    private Button lostKeyButton;
    private KeyMapping listening; // the key binding currently waiting for a key press, or null

    public DeathCamSettingsScreen() {
        super(Component.literal("DeathCam Settings"));
    }

    @Override
    protected void init() {
        listening = null;
        int center = this.width / 2;
        int y = Math.max(6, this.height / 2 - 130);
        final int step = 24;

        // Speed: slider (0-5) plus a type box; both stay in sync and are clamped to 0-5.
        speedSlider = new SpeedSlider(center - 105, y, 140, 20);
        this.addRenderableWidget(speedSlider);

        speedBox = new EditBox(this.font, center + 41, y, 64, 20, Component.literal("Speed"));
        speedBox.setMaxLength(4);
        lastValidText = fmt(DeathCamConfig.speed);
        speedBox.setValue(lastValidText);
        speedBox.setResponder(this::onSpeedTyped);
        this.addRenderableWidget(speedBox);
        y += step;

        // Reanimate: walk on the ground as a ghost instead of flying. Closes the menu so you can play.
        this.addRenderableWidget(Button.builder(
                Component.literal(DeathCam.isGhost() ? "Stop reanimating (back to freecam)" : "Reanimate (walk as a ghost)"),
                button -> {
                    DeathCam.setGhostMode(Minecraft.getInstance(), !DeathCam.isGhost());
                    onClose();
                }).bounds(center - 105, y, 210, 20).build());
        y += step;

        // Second Chance: an extra (client-side) life with hearts and fall damage. Needs Reanimate.
        Button superButton = Button.builder(superLabel(), button -> {
            DeathCam.setSuperLife(!DeathCam.isSuperLife());
            button.setMessage(superLabel());
        }).bounds(center - 105, y, 210, 20).build();
        superButton.active = DeathCam.isGhost();
        this.addRenderableWidget(superButton);
        y += step;

        this.addRenderableWidget(Button.builder(toggleLabel("Smooth movement", DeathCamConfig.smoothMovement), button -> {
            DeathCamConfig.smoothMovement = !DeathCamConfig.smoothMovement;
            DeathCamConfig.save();
            button.setMessage(toggleLabel("Smooth movement", DeathCamConfig.smoothMovement));
        }).bounds(center - 105, y, 210, 20).build());
        y += step;

        this.addRenderableWidget(Button.builder(toggleLabel("Freecam HUD", DeathCamConfig.showHud), button -> {
            DeathCamConfig.showHud = !DeathCamConfig.showHud;
            DeathCamConfig.save();
            button.setMessage(toggleLabel("Freecam HUD", DeathCamConfig.showHud));
        }).bounds(center - 105, y, 210, 20).build());
        y += step;

        this.addRenderableWidget(Button.builder(hotbarLabel(), button -> {
            DeathCamConfig.hotbarAnimation = (DeathCamConfig.hotbarAnimation + 1) % 4;
            DeathCamConfig.save();
            button.setMessage(hotbarLabel());
        }).bounds(center - 105, y, 210, 20).build());
        y += step;

        this.addRenderableWidget(Button.builder(Component.literal("View lost items"), button ->
                Minecraft.getInstance().gui.setScreen(new LostItemsScreen(this))
        ).bounds(center - 105, y, 210, 20).build());
        y += step + 6;

        // Keybinds: click a button, then press the new key (Esc cancels).
        menuKeyButton = Button.builder(Component.empty(), button -> startListening(DeathCam.menuKey()))
                .bounds(center - 105, y, 103, 20).build();
        lostKeyButton = Button.builder(Component.empty(), button -> startListening(DeathCam.lostItemsKey()))
                .bounds(center + 2, y, 103, 20).build();
        this.addRenderableWidget(menuKeyButton);
        this.addRenderableWidget(lostKeyButton);
        refreshKeyButtons();
        y += step;

        this.addRenderableWidget(Button.builder(Component.literal("Reset keybinds"), button -> {
            resetKey(DeathCam.menuKey());
            resetKey(DeathCam.lostItemsKey());
            KeyMapping.resetMapping();
            Minecraft.getInstance().options.save();
            listening = null;
            refreshKeyButtons();
        }).bounds(center - 105, y, 210, 20).build());
        y += step + 6;

        this.addRenderableWidget(Button.builder(Component.literal("Done"), button -> onClose())
                .bounds(center - 105, y, 210, 20).build());
    }

    // ---- keybinds ---------------------------------------------------------------------------------

    private void startListening(KeyMapping key) {
        listening = key;
        refreshKeyButtons();
    }

    private static void resetKey(KeyMapping key) {
        if (key != null) key.setKey(key.getDefaultKey());
    }

    private void refreshKeyButtons() {
        if (menuKeyButton != null) menuKeyButton.setMessage(keyLabel("Menu", DeathCam.menuKey()));
        if (lostKeyButton != null) lostKeyButton.setMessage(keyLabel("Lost items", DeathCam.lostItemsKey()));
    }

    private Component keyLabel(String name, KeyMapping key) {
        if (key == listening) return Component.literal(name + ": > press a key <");
        return Component.literal(name + ": ").append(key.getTranslatedKeyMessage());
    }

    // ---- speed ------------------------------------------------------------------------------------

    private static String fmt(double v) {
        return java.math.BigDecimal.valueOf(Math.round(v * 100.0) / 100.0).stripTrailingZeros().toPlainString();
    }

    /** Updates the in-memory speed only; it is written to disk once, when this screen closes. */
    private void setSpeed(double v) {
        DeathCamConfig.speed = Math.round(DeathCamConfig.clamp(v, DeathCamConfig.MIN_SPEED, DeathCamConfig.MAX_SPEED) * 100.0) / 100.0;
    }

    /** Called for every edit of the type box. Out-of-range numbers snap to 0 or 5. */
    private void onSpeedTyped(String text) {
        if (updatingBox) return;

        // EditBox#setFilter doesn't exist in 26.2, so validate here: reject anything that isn't a plain number.
        if (!text.matches("\\d{0,2}(\\.\\d{0,2})?")) {
            updatingBox = true;
            speedBox.setValue(lastValidText);
            updatingBox = false;
            return;
        }
        lastValidText = text;

        double parsed;
        try { parsed = Double.parseDouble(text); }
        catch (NumberFormatException e) { return; } // empty or "." while typing: wait for a real number

        double clamped = DeathCamConfig.clamp(parsed, DeathCamConfig.MIN_SPEED, DeathCamConfig.MAX_SPEED);
        setSpeed(clamped);
        if (clamped != parsed) {
            updatingBox = true;
            lastValidText = fmt(clamped);
            speedBox.setValue(lastValidText);
            updatingBox = false;
        }
        speedSlider.syncFromConfig();
    }

    private final class SpeedSlider extends AbstractSliderButton {
        SpeedSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Component.empty(), DeathCamConfig.speed / DeathCamConfig.MAX_SPEED);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Component.literal("Freecam speed: " + fmt(this.value * DeathCamConfig.MAX_SPEED)));
        }

        @Override
        protected void applyValue() {
            setSpeed(this.value * DeathCamConfig.MAX_SPEED);
            if (speedBox != null) {
                updatingBox = true;
                lastValidText = fmt(DeathCamConfig.speed);
                speedBox.setValue(lastValidText);
                updatingBox = false;
            }
        }

        void syncFromConfig() {
            this.value = DeathCamConfig.speed / DeathCamConfig.MAX_SPEED;
            updateMessage();
        }
    }

    private static Component superLabel() {
        if (!DeathCam.isGhost()) return Component.literal("Second Chance (needs Reanimate)");
        return Component.literal("Second Chance: " + (DeathCam.isSuperLife() ? "ON" : "OFF"));
    }

    private static Component hotbarLabel() {
        String mode = switch (DeathCamConfig.hotbarAnimation) {
            case 1 -> "Opacity";
            case 2 -> "Size";
            case 3 -> "Opacity + size";
            default -> "Off";
        };
        return Component.literal("Hotbar selector: " + mode);
    }

    private static Component toggleLabel(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    // ---- input / lifecycle --------------------------------------------------------------------------

    // A focused text box swallows key presses before the key binding system sees them, so we catch keys
    // here, before any widget does: first for rebinding, then for the menu key closing this screen.
    @Override
    public boolean keyPressed(KeyEvent event) {
        if (listening != null) {
            KeyMapping target = listening;
            listening = null;
            if (event.key() != InputConstants.KEY_ESCAPE && event.key() != InputConstants.UNKNOWN.getValue()) {
                target.setKey(InputConstants.Type.KEYSYM.getOrCreate(event.key()));
                KeyMapping.resetMapping();
                Minecraft.getInstance().options.save();
            }
            refreshKeyButtons();
            return true;
        }
        if (DeathCam.isMenuKey(event)) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }

    @Override
    public void removed() {
        DeathCamConfig.save(); // one disk write instead of one per slider tick / keystroke
        super.removed();
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().gui.setScreen(null);
    }
}
