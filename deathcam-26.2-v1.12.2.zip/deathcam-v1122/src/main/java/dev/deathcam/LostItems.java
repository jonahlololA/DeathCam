package dev.deathcam;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/**
 * Client-side record of what you were carrying (and your XP) when you died. Items still drop as normal (the
 * server decides that); this just remembers them so you can see what you lost, and so Second Chance can give
 * you a local copy to use.
 */
public final class LostItems {
	private static final int HISTORY = 20; // about a second of snapshots, in case the server empties the inventory a few ticks before death shows

	private record Snap(ItemStack[] items, int level, float progress) {}

	private static final Snap[] history = new Snap[HISTORY];
	private static Snap lost;      // null = nothing recorded yet
	private static boolean wasAlive;

	private LostItems() {}

	public static ItemStack[] lost() { return lost == null ? null : lost.items(); }
	public static int lostLevel() { return lost == null ? 0 : lost.level(); }
	public static float lostProgress() { return lost == null ? 0.0F : lost.progress(); }

	public static void clear() {
		for (int i = 0; i < HISTORY; i++) history[i] = null;
		lost = null;
		wasAlive = false;
	}

	public static void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null || mc.level == null) { clear(); return; }

		boolean dead = p.isDeadOrDying();

		if (!dead) {
			// keep the last few alive-snapshots; the newest is index 0
			for (int i = HISTORY - 1; i > 0; i--) history[i] = history[i - 1];
			history[0] = snapshot(p);
			wasAlive = true;
		} else if (wasAlive) {
			// Died this tick. Normally the newest snapshot is right, but if the server's "inventory
			// cleared" update landed a tick before the death state did, the newest one is empty - fall back.
			Snap pick = history[0];
			for (Snap h : history) {
				if (h != null && count(h.items()) > 0) { pick = h; break; }
			}
			lost = pick;
			for (int i = 0; i < HISTORY; i++) history[i] = null; // don't leak this life into the next
			wasAlive = false;
		}
	}

	public static int count(ItemStack[] stacks) {
		int c = 0;
		for (ItemStack s : stacks) if (s != null && !s.isEmpty()) c++;
		return c;
	}

	private static Snap snapshot(LocalPlayer p) {
		Inventory inv = p.getInventory();
		int n = inv.getContainerSize();
		ItemStack[] out = new ItemStack[n];
		for (int i = 0; i < n; i++) out[i] = inv.getItem(i).copy();
		return new Snap(out, p.experienceLevel, p.experienceProgress);
	}
}
