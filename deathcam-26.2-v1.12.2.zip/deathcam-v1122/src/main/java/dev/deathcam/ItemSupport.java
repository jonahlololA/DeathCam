package dev.deathcam;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * What an item can do during Super Death. Everything is client-side, and the client cannot create entities or
 * run server-only game logic, so a whole class of items can never work. This class knows which, tells you why,
 * and can write a report of EVERY item in the game's registry (generated in-game, so it also covers modded items).
 */
public final class ItemSupport {
	private ItemSupport() {}

	public enum Kind { PLACEABLE, BUCKET, FOOD, GHOST, NEEDS_SERVER, MINING_ONLY }

	private static final Set<String> PROJECTILE_LIKE = Set.of(
			"bow", "crossbow", "trident", "snowball", "egg", "blue_egg", "brown_egg", "ender_pearl",
			"wind_charge", "experience_bottle", "splash_potion", "lingering_potion", "firework_rocket",
			"fishing_rod", "ender_eye");
	private static final Set<String> ENTITY_ITEMS = Set.of(
			"armor_stand", "item_frame", "glow_item_frame", "painting", "end_crystal", "lead");
	/** Items that spawn an entity when placed. They cannot exist client-side, so Super Death places a visual "ghost item". */
	private static final Set<String> GHOST_NAMES = Set.of(
			"armor_stand", "item_frame", "glow_item_frame", "painting", "end_crystal");
	private static final Set<String> SERVER_EFFECT = Set.of(
			"potion", "milk_bucket", "bone_meal", "shears", "brush", "flint_and_steel", "spyglass_use");

	private static boolean reported;

	public static Kind kind(Item item) {
		if (item instanceof BlockItem) return Kind.PLACEABLE;
		if (item == Items.WATER_BUCKET || item == Items.LAVA_BUCKET) return Kind.BUCKET;
		if (item.components().has(DataComponents.FOOD)) return Kind.FOOD;
		if (ghostPlaceable(item)) return Kind.GHOST;
		if (serverReason(item) != null) return Kind.NEEDS_SERVER;
		return Kind.MINING_ONLY;
	}

	/**
	 * Items that get placed as client-side ghost items on right click: everything that has no other right-click job
	 * here (potions, boats, spawn eggs, ingots, books, armor, ...). Blocks, water/lava/empty buckets, food and
	 * tools keep their normal behaviour, except that with Shift held (crouching) tools, food and the rest can be
	 * placed as ghosts too.
	 */
	public static boolean ghostPlaceable(Item item, boolean crouching) {
		if (item == Items.AIR || item instanceof BlockItem) return false;
		if (item == Items.BUCKET || item == Items.WATER_BUCKET || item == Items.LAVA_BUCKET) return false;
		if (crouching) return true;
		if (item.components().has(DataComponents.FOOD)) return false;
		if (item.components().has(DataComponents.TOOL)) return false;
		return true;
	}

	public static boolean ghostPlaceable(Item item) { return ghostPlaceable(item, false); }

	/**
	 * Items that stand for a real entity get that entity drawn (client-side only) when placed as a ghost: boats,
	 * rafts, minecarts, armor stands, end crystals and spawn eggs (the mob the egg spawns). Returns the entity's
	 * registry name, or null when the item is shown as a plain item drop instead.
	 */
	public static String entityIdFor(Item item) {
		String p = BuiltInRegistries.ITEM.getKey(item).getPath();
		if (p.endsWith("_boat") || p.endsWith("_raft") || p.contains("minecart")) return p;
		if (p.endsWith("_spawn_egg")) return p.substring(0, p.length() - "_spawn_egg".length());
		if (p.equals("armor_stand") || p.equals("end_crystal")) return p;
		return null;
	}

	/** Why this item cannot do its normal job client-side, or null if there is nothing we know of that blocks it. */
	public static String serverReason(Item item) {
		if (item instanceof BlockItem || item == Items.WATER_BUCKET || item == Items.LAVA_BUCKET) return null;
		if (ghostPlaceable(item)) return null; // these get a ghost placed instead of an explanation
		String p = BuiltInRegistries.ITEM.getKey(item).getPath();
		if (p.contains("minecart")) return "minecarts are entities, and entities only exist on the server";
		if (p.endsWith("_boat") || p.endsWith("_raft")) return "boats are entities, and entities only exist on the server";
		if (p.endsWith("_spawn_egg")) return "spawning mobs is done by the server";
		if (PROJECTILE_LIKE.contains(p)) return "projectiles are entities, and entities only exist on the server";
		if (ENTITY_ITEMS.contains(p)) return "it creates or uses an entity, which only exists on the server";
		if (p.endsWith("_bucket")) return "scooping, milk and mobs in buckets are handled by the server";
		if (p.endsWith("_hoe") || p.endsWith("_axe") || p.endsWith("_shovel")) {
			return "its right-click action is done by the server (mining still works)";
		}
		if (SERVER_EFFECT.contains(p)) return "its effect is applied by the server";
		return null;
	}

	/** Writes config/deathcam-items.txt listing every registered item and what it can do. Safe to call repeatedly. */
	public static void writeReportOnce() {
		if (reported) return;
		reported = true;
		try {
			List<String> placeable = new ArrayList<>(), buckets = new ArrayList<>(), food = new ArrayList<>(),
					ghosts = new ArrayList<>(), needs = new ArrayList<>(), mining = new ArrayList<>();
			int total = 0;
			for (Item item : BuiltInRegistries.ITEM) {
				total++;
				String id = BuiltInRegistries.ITEM.getKey(item).toString();
				switch (kind(item)) {
					case PLACEABLE -> placeable.add(id);
					case BUCKET -> buckets.add(id);
					case FOOD -> food.add(id);
					case GHOST -> ghosts.add(id);
					case NEEDS_SERVER -> needs.add(id + "   - " + serverReason(item));
					default -> mining.add(id);
				}
			}
			StringBuilder out = new StringBuilder();
			out.append("DeathCam Super Death item report (generated in-game from the item registry)\n");
			out.append("Total items: ").append(total).append("\n\n");
			section(out, "WORKS: place as a block / mine with it (" + placeable.size() + ")", placeable);
			section(out, "WORKS: pour water or lava (" + buckets.size() + ")", buckets);
			section(out, "WORKS: eat to refill hunger, hold right click (" + food.size() + ")", food);
			section(out, "GHOST ITEMS: right click places a client-side copy (a real-looking entity where one exists, else an item drop) that only you can see; Shift+right click works for any item (" + ghosts.size() + ")", ghosts);
			section(out, "CANNOT WORK client-side (" + needs.size() + ")", needs);
			section(out, "NO RIGHT-CLICK USE (mining with it works) (" + mining.size() + ")", mining);
			Path file = FabricLoader.getInstance().getConfigDir().resolve("deathcam-items.txt");
			Files.writeString(file, out.toString());
		} catch (Exception | LinkageError e) {
			System.err.println("[deathcam] could not write the item report: " + e);
		}
	}

	private static void section(StringBuilder out, String title, List<String> lines) {
		out.append("== ").append(title).append(" ==\n");
		for (String line : lines) out.append(line).append('\n');
		out.append('\n');
	}
}
